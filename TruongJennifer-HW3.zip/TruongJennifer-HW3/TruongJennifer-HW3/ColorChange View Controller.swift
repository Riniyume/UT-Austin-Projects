//
//  Project: TruongJennifer-HW3
//  EID: Jat5244
//  Course: CS329E
//
//  ColorChange View Controller.swift
//  TruongJennifer-HW3
//
//  Created by Jennifer Truong on 9/17/23.
//

import UIKit

class ColorChangeViewController: UIViewController {

    var delegate: UIViewController!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func blueButtonPressed(_ sender: Any) {
        // Changing the background text color to Blue
        let anotherVC = delegate as! TextChanger
        anotherVC.changeColor(newColor: .blue)
        
        // Dismiss the ColorChange ViewController
        self.dismiss(animated: true)
    }
    
    
    @IBAction func redButtonPressed(_ sender: Any) {
        // Changing the background text color to Blue
        let anotherVC2 = delegate as! TextChanger
        anotherVC2.changeColor(newColor: .red)
        
        // Dismiss the ColorChange ViewController
        self.dismiss(animated: true)
    }
}
