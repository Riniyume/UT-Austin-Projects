//
//  Project: TruongJennifer-HW3
//  EID: Jat5244
//  Course: CS329E
//
//  Protocols.swift
//  TruongJennifer-HW3
//
//  Created by Jennifer Truong on 9/19/23.
//

import UIKit

// Have the protocol in a new separate swift file
protocol TextChanger {
    func changeText(newTextString:String)
    func changeColor(newColor: UIColor)
}
