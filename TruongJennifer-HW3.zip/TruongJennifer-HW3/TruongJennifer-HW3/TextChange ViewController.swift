//
//  Project: TruongJennifer-HW3
//  EID: Jat5244
//  Course: CS329E
//
//  TextChange View Controller.swift
//  TruongJennifer-HW3
//
//  Created by Jennifer Truong on 9/17/23.
//

import UIKit

class TextChangeViewController: UIViewController {
    
    
    @IBOutlet weak var textField: UITextField!
    
    var delegate: UIViewController!
    var newTextChange = ""  // Initialize the string
    
    override func viewDidLoad() {
        super.viewDidLoad()
        textField.text = newTextChange
    }
    
    @IBAction func saveButtonPressed(_ sender: Any) {
        // Changing the initial text to what the user wants
        let otherVC = delegate as! TextChanger
        otherVC.changeText(newTextString: textField.text!)
        
        // Dismiss the TextChange ViewController
        self.dismiss(animated: true)
    }

}
