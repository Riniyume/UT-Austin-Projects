//
//  Project: TruongJennifer-HW3
//  EID: Jat5244
//  Course: CS329E
//
//  ViewController.swift
//  TruongJennifer-HW3
//
//  Created by Jennifer Truong on 9/17/23.
//

import UIKit

class ViewController: UIViewController, TextChanger {

    @IBOutlet weak var initialText: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set the initial label text
        initialText.text = "Text goes here"
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // For Text Change Segue
        if segue.identifier == "TextChangeSegue",
           let textChangeVC = segue.destination as? TextChangeViewController
        {
            textChangeVC.delegate = self
            textChangeVC.newTextChange = initialText.text!
        }
        
        // For Color Change Segue
        if segue.identifier == "ColorChangeSegue",
           let colorChangeVC = segue.destination as? ColorChangeViewController
        {
            colorChangeVC.delegate = self
        }
        
    }
    
    // Protocol functions:
    
    // Changing the text
    func changeText(newTextString: String) {
        initialText.text = newTextString
    }
    // Changing the text background color
    func changeColor(newColor: UIColor) {
        initialText.backgroundColor = newColor
    }
}

