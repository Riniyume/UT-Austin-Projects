from collections import defaultdict
import re
import io

def main():
    f = io.open("Cook book.txt", encoding='utf-8')
    w1 = open("allwords.txt", "w")
    w2 = open("uniquewords.txt", "w")
    w3 = open("wordfrequency.txt", "w")
    d1 = defaultdict(int)
    d2 = defaultdict(int)
    p = re.compile(r'[a-z]+')
    words = []
    for line in f:
        line = line.lower()
        res = p.findall(line)
        words.append(res)
    for x in words:
        for y in x:
            w1.write(y + '\n')
            d1[y] += 1
    for i in d1:
        if (d1[i] == 1):
            w2.write(str(i) + '\n')

    for j in d1.values():
        d2[j] +=1

    
    items = list(d2.items())
    items.sort(key=lambda x:x[0])
    for item in items:
        w3.write(str(item[0]) + ": " + str(item[1]) + "\n")
    w1.close()
    w2.close()
    w3.close()

if __name__ == "__main__":   
    main()
