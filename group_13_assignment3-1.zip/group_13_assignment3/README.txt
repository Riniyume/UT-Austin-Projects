Directions: 

Open the extract_words.py file and run the program.
Open the .pde and click "Run" to start the program. 
For a3_novelvisualization.pde file, click on the cavas will display a new selection of words
