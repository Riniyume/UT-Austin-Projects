Directions: open .pde and click "Run" to start the program. 
-----------------------------------------------------------------------------------------------------------------------------

It will display the contents in "mytext.txt" onto the screen, and the other part will have the "typewriter" portion...
except that I didn't figure out how to do backspace or return for it.