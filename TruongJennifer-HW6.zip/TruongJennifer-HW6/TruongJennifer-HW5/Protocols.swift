//
//  Project: TruongJennifer-HW6
//  EID: Jat5244
//  Course: CS329E
//
//  Protocols.swift
//  TruongJennifer-HW5
//
//  Created by Jennifer Truong on 10/11/23.
//

import Foundation

// Have the protocols in a separate swift file
protocol PizzaCreationDelegate: AnyObject {
    func didCreatePizza(_ pizza: Pizza)
}

// For the Signout button
protocol SignOutDelegate: AnyObject {
    func didSignOut()
}
