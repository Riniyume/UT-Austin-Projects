//
//  Project: TruongJennifer-HW6
//  EID: Jat5244
//  Course: CS329E
//
//  ViewController.swift
//  TruongJennifer-HW5
//
//  Created by Jennifer Truong on 10/8/23.
//

import UIKit
import Foundation
import CoreData
import FirebaseAuth

// Pointer to something outside of the app
let appDelegate = UIApplication.shared.delegate as! AppDelegate
// Creating a buffer, lazy way, note pad
let context = appDelegate.persistentContainer.viewContext

// Create pizza class to store the pizza information
class Pizza {
    var pSize: String
    var crust: String
    var cheese: String
    var meat: String
    var veggies: String
    
    // initialize the pizza ingredient variables
    init(pSize: String, crust: String, cheese: String, meat: String, veggies: String) {
        self.pSize = pSize
        self.crust = crust
        self.cheese = cheese
        self.meat = meat
        self.veggies = veggies
    }
}

// Create the list to store the Pizzas as user adds
var pizzaList: [Pizza] = []

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, PizzaCreationDelegate {
    
    @IBOutlet weak var tableView: UITableView!
    
    weak var signOutDelegate: SignOutDelegate?
    
    let textCellIdentifier = "TextCell"
    let segueAddButtonIdentifier = "createPizzaSegueIdentifier"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Set the data source and delegate for the table view
        tableView.delegate = self
        tableView.dataSource = self
        
        // Load pizza data from Core Data
        pizzaList = loadPizza()
        
        // Reload the table view to reflect the updated pizzaList
        tableView.reloadData()
    }
    
    // Handle the action when the user wants to create a new pizza
    @IBAction func createNewPizza(_ sender: Any) {
        // Check if the "+" button was tapped
        if segueAddButtonIdentifier == "createPizzaSegueIdentifier" {
            // Perform the segue to create a new pizza
            performSegue(withIdentifier: segueAddButtonIdentifier, sender: nil)
        }
    }
    
    // Return the number of rows in the table view
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return pizzaList.count
    }
    
    // Configure and return a cell for a given index path
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: textCellIdentifier, for: indexPath as IndexPath)
        let row = indexPath.row
        let pizza = pizzaList[row]
        
        // Display the pizza details in the cell
        cell.textLabel?.text = "\(pizza.pSize.lowercased()) \n\n\t\(pizza.crust) \n\n\t\(pizza.cheese) \n\n\t\(pizza.meat) \n\n\t\(pizza.veggies)"
        return cell
    }
    
    // Deletion Swipe on the table view
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Remove the pizza from your data source (pizzaList)
            let deletedPizza = pizzaList.remove(at: indexPath.row)
            
            // Delete the corresponding Core Data record
            clearPizza(pizza: deletedPizza)
            
            // Update the table view
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
    }
    
    // Implement the delegate method to add the created pizza to the pizzaList
    func didCreatePizza(_ pizza: Pizza) {
        // Append the created pizza to the pizzaList
        pizzaList.append(pizza)
        
        // Reload the table view to reflect the updated pizzaList
        tableView.reloadData()
    }
    
    // Prepare for a segue to pass data to the destination view controller
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == segueAddButtonIdentifier {
            
            if let destinationVC = segue.destination as? PizzaCreationViewController {
                // Set the delegate to self to establish the connection
                destinationVC.delegate = self
            }
        }
        
    }
    
    // Load in the pizza to the table view
    func loadPizza() -> [Pizza] {
        let fetchRequest: NSFetchRequest<NSManagedObject> = NSFetchRequest(entityName: "PizzaObject")

        do {
            let fetchedResults = try context.fetch(fetchRequest)
            var pizzaList = [Pizza]() // Create a new array to store the fetched data

            for managedObject in fetchedResults {
                guard
                    let size = managedObject.value(forKey: "size") as? String,
                    let crust = managedObject.value(forKey: "crust") as? String,
                    let cheese = managedObject.value(forKey: "cheese") as? String,
                    let meat = managedObject.value(forKey: "meat") as? String,
                    let veggies = managedObject.value(forKey: "veggies") as? String
                else {
                    continue
                }
                let pizza = Pizza(pSize: size, crust: crust, cheese: cheese, meat: meat, veggies: veggies)
                pizzaList.append(pizza)
            }

            return pizzaList
        } catch {
            print("Error occurred while retrieving data: \(error)")
            return []
        }
    }
    
    // Delete the pizza from Core Data
    func clearPizza(pizza: Pizza) {
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "PizzaObject")
        
        // Construct a predicate based on the unique identifier of the pizza
        let predicate = NSPredicate(format: "#size = %@ AND crust = %@ AND cheese = %@ AND meat = %@ AND veggies = %@", pizza.pSize, pizza.crust, pizza.cheese, pizza.meat, pizza.veggies)
        
        request.predicate = predicate
        
        do {
            if let result = try context.fetch(request) as? [NSManagedObject], let firstObject = result.first {
                context.delete(firstObject)
                saveContext()
            }
        } catch {
            print("Error occurred while deleting data: \(error)")
        }
    }
    
    // Retrieve the Pizza information from the PizzaEntityObject
    func retrievePizza() -> [NSManagedObject] {
        // Create a fetch request for the "PizzaObject" entity
        let fetchRequest: NSFetchRequest<NSManagedObject> = NSFetchRequest(entityName: "PizzaObject")

        do {
            // Fetch the PizzaObjects from Core Data
            let fetchedResults = try context.fetch(fetchRequest)
            return fetchedResults
        } catch {
            print("Error occurred while retrieving data: \(error)")
            return []
        }
    }
    
    // Save the information if there's any changes
    func saveContext () {
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }
    
    // Signs out the current user
    @IBAction func signOutButtonPressed(_ sender: Any) {
        do {
            try Auth.auth().signOut()
            // Notify the delegate about the sign-out action
            signOutDelegate?.didSignOut()
            self.dismiss(animated: true, completion: nil)
        } catch {
            print("Sign out error")
        }
    }
    
}

