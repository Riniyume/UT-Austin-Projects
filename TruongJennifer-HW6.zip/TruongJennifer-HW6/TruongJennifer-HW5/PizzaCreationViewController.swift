//
//  Project: TruongJennifer-HW6
//  EID: Jat5244
//  Course: CS329E
//
//  PizzaCreationViewController.swift
//  TruongJennifer-HW5
//
//  Created by Jennifer Truong on 10/8/23.
//

import UIKit
import CoreData

class PizzaCreationViewController: UIViewController {

    @IBOutlet weak var sizeControl: UISegmentedControl!
    @IBOutlet weak var pizzaOrderLabel: UILabel!
    
    // Define properties to store the selected options
    var selectedCrust: String = ""
    var selectedCheese: String = ""
    var selectedMeat: String = ""
    var selectedVeggies: String = ""
    var selectedSize: String = ""
    
    // Define a delegate property
    weak var delegate: PizzaCreationDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Small pizza is default, and I don't know why my switch case wasn't working
        // so this is a roundabout fix
        self.selectedSize = "Small"
    }
    
    // When the user selects the pizza size, set the selectedSize property
    @IBAction func sizeControlValueChanged(_ sender: UISegmentedControl) {
        switch sender.selectedSegmentIndex {
        case 0:
            self.selectedSize = "small"
        case 1:
            self.selectedSize = "medium"
        case 2:
            self.selectedSize = "large"
        default:
            self.selectedSize = "small"
            break
        }
    }
    
    // Show the error alert message
    func showAlert(message: String) {
        let alertController = UIAlertController(
            title: "Missing Ingredient",
            message: message,
            preferredStyle: .alert)
        
        alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            
        present(alertController, animated: true, completion: nil)
    }

    @IBAction func crustButtonPressed(_ sender: Any) {
        // Create an alert controller to let the user choose a crust type
        let crustController = UIAlertController(
            title: "Select crust",
            message: "Choose a crust type:",
            preferredStyle: .alert)
        
        // Add action for "thin crust" with a closure to set the selectedCrust property
        crustController.addAction(UIAlertAction(title: "Thin crust", style: .default, handler: { _ in
            self.selectedCrust = "thin crust"
        }))
        
        // Add action for "thick crust" with a closure to set the selectedCrust property
        crustController.addAction(UIAlertAction(title: "Thick crust", style: .default, handler: { _ in
            self.selectedCrust = "thick crust"
        }))
        
        // Present the crust controller as an alert
        present(crustController, animated: true)
    }
    
    @IBAction func cheeseButtonPressed(_ sender: Any) {
        // Create an alert controller to let the user choose a cheese type
        let cheeseController = UIAlertController(
            title: "Select cheese",
            message: "Choose a cheese type:",
            preferredStyle: .alert)
        
        // Add actions for various cheese options with closures to set the
        // selectedCheese property
        cheeseController.addAction(UIAlertAction(title: "Regular cheese", style: .default, handler: { _ in
            self.selectedCheese = "regular cheese"
        }))
        cheeseController.addAction(UIAlertAction(title: "No cheese", style: .default, handler: { _ in
            self.selectedCheese = "no cheese"
        }))
        cheeseController.addAction(UIAlertAction(title: "Double cheese", style: .default, handler: { _ in
            self.selectedCheese = "double cheese"
        }))
        
        // Present the cheese controller as an alert
        present(cheeseController, animated: true)
    }
    
    @IBAction func meatButtonPressed(_ sender: Any) {
        // Create an alert controller to let the user choose a meat type
        let meatController = UIAlertController(
            title: "Select meat",
            message: "Choose one meat:",
            preferredStyle: .alert)
        
        // Add actions for various meat options with closures to set the
        // selectedMeat property
        meatController.addAction(UIAlertAction(title: "Pepperoni", style: .default, handler: { _ in
            self.selectedMeat = "pepperoni"
        }))
        meatController.addAction(UIAlertAction(title: "Sausage", style: .default, handler: { _ in
            self.selectedMeat = "sausage"
        }))
        meatController.addAction(UIAlertAction(title: "Canadian Bacon", style: .default, handler: { _ in
            self.selectedMeat = "canadian Bacon"
        }))
        
        // Present the meat controller as an alert
        present(meatController, animated: true)
    }
    
    @IBAction func veggiesButtonPressed(_ sender: Any) {
        // Create an alert controller to let the user choose a veggie type
        let veggieController = UIAlertController(
            title: "Select veggies",
            message: "Choose your veggies:",
            preferredStyle: .alert)
        
        // Add actions for various veggies options with closures to set the
        // selectedVeggies property
        veggieController.addAction(UIAlertAction(title: "Mushroom", style: .default, handler: { _ in
            self.selectedVeggies = "mushroom"
        }))
        veggieController.addAction(UIAlertAction(title: "Onion", style: .default, handler: { _ in
            self.selectedVeggies = "onion"
        }))
        veggieController.addAction(UIAlertAction(title: "Green Olive", style: .default, handler: { _ in
            self.selectedVeggies = "green Olive"
        }))
        veggieController.addAction(UIAlertAction(title: "Black Olive", style: .default, handler: { _ in
            self.selectedVeggies = "black Olive"
        }))
        veggieController.addAction(UIAlertAction(title: "None", style: .default, handler: { _ in
            self.selectedVeggies = "none"
        }))
        
        // Present the meat controller as an alert
        present(veggieController, animated: true)
    }
    
    @IBAction func doneButtonPressed(_ sender: Any) {
        // Create an array to store missing selections
        var missingSelections: [String] = []
        
        // Check for missing selections
        if selectedCrust.isEmpty {
            missingSelections.append("crust")
        }
        if selectedCheese.isEmpty {
            missingSelections.append("cheese")
        }
        if selectedMeat.isEmpty {
            missingSelections.append("meat")
        }
        if selectedVeggies.isEmpty {
            missingSelections.append("veggies")
        }
        
        if missingSelections.count >= 2 {
            // If at least two selections are missing, show a single error message
            showAlert(message: "Please select all ingredients.")
        } else if missingSelections.count == 1 {
            // If only one selection is missing, show an error message for that specific missing selection
            showAlert(message: "Please select a \(missingSelections[0]) type.")
        } else {
            // All selections are made, create the pizza and update the summary label
            let pizza = Pizza(pSize: selectedSize, crust: selectedCrust, cheese: selectedCheese, meat: selectedMeat, veggies: selectedVeggies)
                delegate?.didCreatePizza(pizza)
            
            // Display the summary pizza orders in the textLabel
            let pizzaOrderText = "One \(selectedSize.lowercased()) pizza with: \n\t\(selectedCrust) \n\t\(selectedCheese) \n\t\(selectedMeat) \n\t\(selectedVeggies)"
            pizzaOrderLabel.text = pizzaOrderText
            
            // Call the storePizza function to save the pizza to Core Data
            storePizza(pizza: pizza)
            }
    }
    
    // Store the Pizza information into PizzaEntityObject
    func storePizza(pizza: Pizza) {
        // Create a PizzaObject and store it in Core Data
        let pizzaItem = NSEntityDescription.insertNewObject(
            forEntityName: "PizzaObject",
            into: context)
        
        pizzaItem.setValue(pizza.pSize, forKey: "size")
        pizzaItem.setValue(pizza.crust, forKey: "crust")
        pizzaItem.setValue(pizza.cheese, forKey: "cheese")
        pizzaItem.setValue(pizza.meat, forKey: "meat")
        pizzaItem.setValue(pizza.veggies, forKey: "veggies")
        
        // Save the context to persist the changes
        do {
            try context.save()
            print("Pizza saved to Core Data.")
        } catch {
            print("Error saving pizza to Core Data: \(error)")
        }
    }

}
