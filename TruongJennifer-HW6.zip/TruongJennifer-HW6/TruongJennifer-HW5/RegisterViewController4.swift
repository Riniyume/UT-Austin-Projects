//
//  Project: TruongJennifer-HW6
//  EID: Jat5244
//  Course: CS329E
//
//  RegisterViewController4.swift
//  TruongJennifer-HW5
//
//  Created by Jennifer Truong on 10/22/23.
//

import UIKit
import FirebaseAuth

class RegisterViewController4: UIViewController {

    // Outlets to various UI elements
    @IBOutlet weak var userID: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var confirmPassword: UITextField!
    
    @IBOutlet weak var registerButton: UIButton!
    @IBOutlet weak var registerSegment: UISegmentedControl!
    
    @IBOutlet weak var confirmPasswordLabel: UILabel!
    @IBOutlet weak var statusLabel: UILabel!
    
    weak var signOutDelegate: SignOutDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Login screen default: confirm password label and textfield hidden
        // Also have the button label changed
        registerButton.setTitle("Sign In", for: .normal)
        confirmPassword.isHidden = true
        confirmPasswordLabel.isHidden = true
        
        self.statusLabel.text = ""

        // Listen for changes in the user's authentication state
        Auth.auth().addStateDidChangeListener() {
            (auth,user) in
            // If a user is authenticated, perform a segue to another screen
            if user != nil {
                self.performSegue(withIdentifier: "registerSegue", sender: nil)
                self.userID.text = nil      // Clear the user ID text field
                self.password.text = nil    // Clear the password text field
                self.confirmPassword.text = nil     // Clear the confirm password text field
                
                // Idk why my signout isn't working like the way I want to
                // so roundabout fix...
                self.registerSegment.selectedSegmentIndex = 0
                self.registerButton.setTitle("Sign In", for: .normal)
                self.confirmPassword.isHidden = true
                self.confirmPasswordLabel.isHidden = true
            }
        }
    }
    
    // Action triggered when the segmented control is changed
    @IBAction func segmentedControlChanged(_ sender: UISegmentedControl) {
        
        if sender.selectedSegmentIndex == 0 {
               // Log In Screen
               registerButton.setTitle("Sign In", for: .normal)
               confirmPassword.isHidden = true
               confirmPasswordLabel.isHidden = true
           } else {
               // Sign Up Screen
               registerButton.setTitle("Sign Up", for: .normal)
               confirmPassword.isHidden = false
               confirmPasswordLabel.isHidden = false
           }
        
    }
    
    // Action triggered when the "Sign In" or "Sign Up" button is pressed
    @IBAction func signInOrSignUp(_ sender: UIButton) {
        guard let email = userID.text, !email.isEmpty,
              let passwords = password.text, !passwords.isEmpty else {
            statusLabel.text = "Email and password are required."
            return
        }

        if registerSegment.selectedSegmentIndex == 0 {
            // Log In Screen
            Auth.auth().signIn(withEmail: userID.text!, password: password.text!) {
             (authResult,error) in
                if let error = error as NSError? {
                    self.statusLabel.text = "\(error.localizedDescription)"
                } else {
                    self.statusLabel.text = ""
                }
            }
            
        } else {
            // Sign Up Screen
            
            // Check if both password inputs match
            guard let confirmPasswords = confirmPassword.text, confirmPasswords == passwords else {
                statusLabel.text = "Passwords do not match."
                return
            }

            Auth.auth().createUser(withEmail: userID.text!, password: password.text!) {
                (authResult,error) in
                if let error = error as NSError? {
                    self.statusLabel.text = "\(error.localizedDescription)"
                } else {
                    self.statusLabel.text = ""
                }
            }
            
        }
    }
    
    // ??? why is it not working
    // Delegate method for handling sign-out
    func didSignOut() {
        // set the segmented control to the "Sign In" segment
        registerSegment.selectedSegmentIndex = 0

        // - Clear text fields
        userID.text = ""
        password.text = ""
        confirmPassword.text = ""
    }
    
}

