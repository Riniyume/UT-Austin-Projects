Directions:
It's highly recommended that you must have Processing 4.0.1 version in order to run the file correctly. 
Open group_13_assignment7.pde and the Brick Break game will immediately start. Use the mouse to control the direction of
the paddle to clear the bricks. 

Press these specific keys to:
'p' or 'P' = to pause the game
'c' or 'C' = to continue the game
'r' or 'R' = reset the game (only if the game has been paused)
'q' or 'Q' = to quit the game