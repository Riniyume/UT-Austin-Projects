Disclaimer: Please download the minim sound library if you not have already done so, because this program will not work
properly without it! There's a few bugs with the setting menu, sometimes it will glitch when the volume is changed and then
when you try to click the button for "Back", so click outside of the interactive components and then click "Back" for the Menu
screen again. Also, you can only access the setting menu before you start the game, you cannot access it later.

What this final project is about:
The game we have decided to do is similar to Geometry Dash where the user plays as a square block and must get over all the
obstacles in the game with fast speed. The player must carefully avoid the spikes and enemy attacks by jumping and surviving
by the end of the level.

-----------------------------------------------------------------------------------------------------------------------------
How to play and controls:

To move the character:
	- PRESS KEY 'w' 'SPACEBAR' or arrow UP key to jump

Other controls:
	- PRESS 'r' to RESET the game (Reminder: the game will promptly continue and it will count toward the death tracker)
	- PRESS 'g' to TURN ON/OFF GODMODE (to bypass all the obstacles)
	- PRESS 'p' to PAUSE the game
	- PRESS 'c' to CONTINUE the game
	- PRESS 'esc' to EXIT the game