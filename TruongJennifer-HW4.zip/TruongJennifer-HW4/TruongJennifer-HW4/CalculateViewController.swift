//
//  Project: TruongJennifer-HW4
//  EID: Jat5244
//  Course: CS329E
//
//  CalculateViewController.swift
//  TruongJennifer-HW4
//
//  Created by Jennifer Truong on 9/29/23.
//  This is my second attempt at this homework
//

import UIKit

class CalculateViewController: UIViewController {

    // Creating all the connections from CalculateViewController from main.storyboard
    // just in case, and a variable
    @IBOutlet weak var operandLabel1: UILabel!
    @IBOutlet weak var operandLabel2: UILabel!
    
    @IBOutlet weak var inputOperand1: UITextField!
    @IBOutlet weak var inputOperand2: UITextField!
    
    @IBOutlet weak var mathSign: UILabel!
    @IBOutlet weak var result: UILabel!
    
    // to change the operatorLabel aka mathSign
    var selectedOperator = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    // Displaying the operator from the chosen table
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // Set the text of the Operator label to the selected operator
        let signIndex = operations.firstIndex(of: selectedOperator)
        mathSign.text = operationSigns[signIndex!]
        }
    
    // When calculate button is pressed, do the math associated with the tableView cell
    // that was selected by the user.
    @IBAction func calculateButtonPressed(_ sender: Any) {
        
        // Check if both operand fields have valid input
        if let operand1Text = inputOperand1.text, let operand2Text = inputOperand2.text,
           let operand1 = Float(operand1Text), let operand2 = Float(operand2Text)
        {
            // Initializing the results
            var calculatedResult: Float = 0.0
            
            // Calculate the result based on the selected operator
            switch selectedOperator {
            case "Add":
                calculatedResult = operand1 + operand2
            case "Subtract":
                calculatedResult = operand1 - operand2
            case "Multiply":
                calculatedResult = operand1 * operand2
            case "Divide":
                // Check for division by zero
                if operand2 != 0 {
                    calculatedResult = operand1 / operand2
                } else {
                    result.text = "Error: Division by zero"
                    return
                }
                
            default:
                // Handle invalid operator input
                result.text = "Invalid operator"
                return
            }
            
            // Check if the result is an integer and display accordingly
            if floor(calculatedResult) == calculatedResult {
                result.text = "\(Int(calculatedResult))"
            } else {
                result.text = "\(calculatedResult)"
            }
    
        } else {
            result.text = "Invalid input"
        }

    }
}
