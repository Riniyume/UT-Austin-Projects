//
//  Project: TruongJennifer-HW4
//  EID: Jat5244
//  Course: CS329E
//
//  ViewController.swift
//  TruongJennifer-HW4
//
//  Created by Jennifer Truong on 9/29/23.
//  This is my second attempt at this homework
//

import UIKit

// Create a data source for the operations
public let operations = ["Add", "Subtract", "Multiply", "Divide"]
public let operationSigns = ["+", "-", "*", "/"]

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource{
    
    // Create the variables and connections
    @IBOutlet weak var tableView: UITableView!
    
    let textCellIdentifier = "TextCell"
    let segueIdentifier = "CalculateSegueIdentifier"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // the two methods for UITableViewDataSource and UITableViewDelegate
        tableView.delegate = self
        tableView.dataSource = self
    }
    
    // Next two funcs are for getting info from the datasource and implementing it
    // into the tableView
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Counting how many rows there should be for tableView
        return operations.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // Implementing the datasource and count of it into the tableView cell
        let cell = tableView.dequeueReusableCell(withIdentifier: textCellIdentifier, for: indexPath as IndexPath)
        let row = indexPath.row
        cell.textLabel?.text = operations[row]
        return cell
    }
    
    // Preparing for the Segue for CalculateViewController
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == segueIdentifier,
           let destination = segue.destination as? CalculateViewController,
           let mathIndex = tableView.indexPathForSelectedRow?.row
        {
            destination.selectedOperator = operations[mathIndex]
        }
    }

}


