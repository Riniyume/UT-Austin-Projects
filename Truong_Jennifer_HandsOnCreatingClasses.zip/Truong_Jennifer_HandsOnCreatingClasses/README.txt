Directions:
Open the .pde and click "Run" to start the program
------------------------------------------------------------------------------------------------------------------------------

Notes:
I want to not have the "after images" of the spot moving, so I added background in the move() method, but that would work
for only one spot, mainly the second one even if both spots had the same speed. Therefore, I hope it's okay to show the after
images due to the different speeds of the spots. 