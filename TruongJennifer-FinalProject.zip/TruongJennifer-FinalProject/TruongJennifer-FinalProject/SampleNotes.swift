//
//  Project: TruongJennifer-FinalProject
//  EID: jat5244
//  Course: CS329E
//
//  SampleNotes.swift
//  TruongJennifer-FinalProject
//
//  Created by Jennifer Truong on 12/3/23.
//

import Foundation

class Note {
    var title: String
    var content: String

    init(title: String, content: String){
        self.title = title
        self.content = content
    }
}

// Samples of crochet related notes for this app
let sampleNotes = [
    Note(title: "Crochet Project Ideas", content: "Thinking about making a cozy blanket with granny squares."),
    Note(title: "Yarn Shopping List", content: "Need to buy acrylic yarn in pastel colors for the baby blanket."),
    Note(title: "Crochet Pattern", content: "Working on a new pattern for a cute amigurumi animal.")
]
