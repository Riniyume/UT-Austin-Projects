//
//  Project: TruongJennifer-FinalProject
//  EID: jat5244
//  Course: CS329E
//
//  SettingViewController.swift
//  TruongJennifer-FinalProject
//
//  Created by Jennifer Truong on 11/30/23.
//

import UIKit
import FirebaseAuth
import UserNotifications

class SettingViewController: UIViewController {
    
    // Outlets for labels
    @IBOutlet weak var helpLabel: UILabel!
    @IBOutlet weak var aboutNotificationLabel: UILabel!
    @IBOutlet weak var sendFeedbackLabel: UILabel!
    @IBOutlet var supportLabel: UILabel!
    
    // Outlets for switches
    @IBOutlet weak var darkModeSwitch: UISwitch!
    @IBOutlet weak var pushNotificationSwitch: UISwitch!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Check and set the state of switches based on user preferences or saved settings
        darkModeSwitch.isOn = UserDefaults.standard.bool(forKey: "DarkModeEnabled")
        
        // Add actions for switch value changes
        darkModeSwitch.addTarget(self, action: #selector(darkModeSwitchValueChanged(_:)), for: .valueChanged)
        pushNotificationSwitch.addTarget(self, action: #selector(pushNotificationSwitchValueChanged(_:)), for: .valueChanged)
        
        // Update app appearance for dark mode based on UserDefaults
        updateAppAppearanceForDarkMode()
        
        // Add tap gesture recognizers to the labels
        let helpTapGesture = UITapGestureRecognizer(target: self, action: #selector(helpLabelTapped))
        helpLabel.isUserInteractionEnabled = true
        helpLabel.addGestureRecognizer(helpTapGesture)
        
        let aboutNotificationTapGesture = UITapGestureRecognizer(target: self, action: #selector(aboutNotificationLabelTapped))
        aboutNotificationLabel.isUserInteractionEnabled = true
        aboutNotificationLabel.addGestureRecognizer(aboutNotificationTapGesture)
        
        let sendFeedbackTapGesture = UITapGestureRecognizer(target: self, action: #selector(sendFeedbackLabelTapped))
        sendFeedbackLabel.isUserInteractionEnabled = true
        sendFeedbackLabel.addGestureRecognizer(sendFeedbackTapGesture)
        
        let supportTapGesture = UITapGestureRecognizer(target: self, action: #selector(supportLabelTapped))
        supportLabel.isUserInteractionEnabled = true
        supportLabel.addGestureRecognizer(supportTapGesture)
        
        // Check notification authorization status when the view loads
        checkNotificationAuthorizationStatus()
    }
    
    // MARK: - Sign Out and Account Deletion
    
    @IBAction func signOutButtonPressed(_ sender: Any) {
        do {
            try Auth.auth().signOut()
            // Reset
            self.resetUserPreferences()
            // Navigate to app's initial screen
            self.navigateToInitialScreen()
        } catch let error {
            // An error occurred while signing out
            print("Error signing out: \(error.localizedDescription)")
            // Handle the error as needed
        }
    }
    
    
    @IBAction func deleteAccountButtonPressed(_ sender: Any) {
        let alertController = UIAlertController(title: "Delete Account", message: "Are you sure you want to delete your account? All data will be gone and you'll never get it back.", preferredStyle: .alert)
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        let deleteAction = UIAlertAction(title: "Delete", style: .destructive) { _ in
            self.deleteAccount()
        }
        
        alertController.addAction(cancelAction)
        alertController.addAction(deleteAction)
        
        present(alertController, animated: true, completion: nil)
    }
    
    func deleteAccount() {
        // Get the current user from Firebase Auth
        if let user = Auth.auth().currentUser {
            // Delete the user's account
            user.delete { error in
                if let error = error {
                    // An error occurred while deleting the account
                    print("Error deleting account: \(error.localizedDescription)")
                } else {
                    self.resetUserPreferences()
                    // Navigate to app's initial screen
                    self.navigateToInitialScreen()
                }
            }
        }
    }
    
    // MARK: - Dark Mode Switch
    
    @objc func darkModeSwitchValueChanged(_ sender: UISwitch) {
        // Respond to changes in the dark mode switch
        if sender.isOn {
            // Enable dark mode
            overrideUserInterfaceStyle = .dark
            UserDefaults.standard.set(true, forKey: "DarkModeEnabled")
        } else {
            // Enable light mode
            overrideUserInterfaceStyle = .light
            UserDefaults.standard.set(false, forKey: "DarkModeEnabled")
        }
        // Update the app for darkMode setting
        updateAppAppearanceForDarkMode()
    }
    
    func updateAppAppearanceForDarkMode() {
        if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
           let window = windowScene.windows.first {
            let isDarkModeEnabled = UserDefaults.standard.bool(forKey: "DarkModeEnabled")
            
            // Set the window's appearance style based on the updated user's preference
            window.overrideUserInterfaceStyle = isDarkModeEnabled ? .dark : .light
        }
    }
    
    // MARK: - Push Notification Switch
    
    func checkNotificationAuthorizationStatus() {
        UNUserNotificationCenter.current().getNotificationSettings { settings in
            DispatchQueue.main.async {
                self.pushNotificationSwitch.isEnabled = settings.authorizationStatus == .authorized
                self.pushNotificationSwitch.isOn = settings.authorizationStatus == .authorized
                
                if settings.authorizationStatus != .authorized {
                    self.requestNotificationAuthorization()
                }
            }
        }
    }
    
    @objc func pushNotificationSwitchValueChanged(_ sender: UISwitch) {
        if sender.isOn {
            requestNotificationAuthorization()
        } else {
            UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: ["myNotification"])
        }
    }
    
    func requestNotificationAuthorization() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound]) { granted, error in
            if granted {
                print("You're all set!")
                DispatchQueue.main.async {
                    self.scheduleNotification()
                }
            } else if let error = error {
                print("Notification authorization error: \(error.localizedDescription)")
            }
        }
    }
    
    func scheduleNotification() {
        let content = UNMutableNotificationContent()
        content.title = "Come Back to Knotty Stitches!"
        content.subtitle = "Why are you away?! Please come back! There's more patterns to see!"
        content.sound = UNNotificationSound.default
        
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 60, repeats: true)
        
        let request = UNNotificationRequest(identifier: "myNotification", content: content, trigger: trigger)
        
        UNUserNotificationCenter.current().add(request)
    }
    
    // MARK: - Some Helper Functions
    
    func navigateToInitialScreen() {
        if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
           let window = windowScene.windows.first {
            window.rootViewController = UIStoryboard(name: "Main", bundle: nil).instantiateInitialViewController()
            window.makeKeyAndVisible()
        }
    }
    
    func resetUserPreferences() {
        UserDefaults.standard.set(false, forKey: "DarkModeEnabled")
    }
    
    // MARK: - Tap Gesture Actions
    
    // Method to handle tap on the help label
    @objc func helpLabelTapped() {
        showAlert(title: "Help", message: "Here's the support team email if you need help: KnottyStitches@gmail.com. This email doesn't exist, so good luck.")
    }
    
    // Method to handle tap on the about notification label
    @objc func aboutNotificationLabelTapped() {
        showAlert(title: "About Notifications", message: "Information about notifications.")
    }
    
    // Method to handle tap on the send feedback label
    @objc func sendFeedbackLabelTapped() {
        showAlert(title: "Send Feedback", message: "Please leave your feedback on the app! Leave a 5/5 star rating! :)")
    }
    
    // Method to handle tap on the support label
    @objc func supportLabelTapped() {
        showAlert(title: "Support", message: "Lol there is no support, but you can try your luck at KnottyStitches@gmail.com")
    }
    
    // Method to display an alert
    func showAlert(title: String, message: String) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alertController.addAction(okAction)
        present(alertController, animated: true, completion: nil)
    }
}
