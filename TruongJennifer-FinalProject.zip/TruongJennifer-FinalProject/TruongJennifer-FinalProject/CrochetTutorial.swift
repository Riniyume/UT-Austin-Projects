//
//  Project: TruongJennifer-FinalProject
//  EID: jat5244
//  Course: CS329E
//
//  CrochetTutorial.swift
//  TruongJennifer-FinalProject
//
//  Created by Jennifer Truong on 12/2/23.
//


import Foundation

struct CrochetTutorial {
    let title: String
    let difficulty: String
    let description: String
}

// Samples of crochet tutorials for this app
let crochetTutorials = [
    CrochetTutorial(
        title: "Beginner's Guide: Single Crochet Stitch",
        difficulty: "Beginner",
        description: "Learn the basics of the single crochet stitch. Perfect for beginners, this tutorial covers step-by-step instructions and practice tips."
    ),
    CrochetTutorial(
        title: "Mastering the Granny Square",
        difficulty: "Intermediate",
        description: "Dive into the versatile world of granny squares! Explore different patterns, color combinations, and techniques to create beautiful squares."
    ),
    CrochetTutorial(
        title: "Creating Intricate Lace Patterns",
        difficulty: "Advanced",
        description: "Unlock the art of crocheting intricate lace designs. This tutorial guides you through advanced techniques for stunning lacework."
    ),
    CrochetTutorial(
        title: "Amigurumi: Crocheting Cute Creatures",
        difficulty: "Intermediate",
        description: "Discover the adorable world of amigurumi! Learn how to crochet cute animals, characters, and more in this fun tutorial."
    ),
    CrochetTutorial(
        title: "Crocheting with Different Yarn Weights",
        difficulty: "Intermediate",
        description: "Explore the effects of using different yarn weights in your crochet projects. Tips and tricks for adjusting patterns included."
    )
]
