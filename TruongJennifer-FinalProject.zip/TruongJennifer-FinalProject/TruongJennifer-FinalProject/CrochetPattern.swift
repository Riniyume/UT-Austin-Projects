//
//  Project: TruongJennifer-FinalProject
//  EID: jat5244
//  Course: CS329E
//
//  CrochetPattern.swift
//  TruongJennifer-FinalProject
//
//  Created by Jennifer Truong on 12/2/23.
//

struct CrochetPattern {
    let name: String
    let category: String
    let instructions: String
}

// Samples of crochet patterns for this app
let crochetPatterns = [
    CrochetPattern(
        name: "Classic Granny Square",
        category: "Square Patterns",
        instructions: """
        Row 1: Start with a magic ring, ch 3 (counts as dc), 2 dc into the ring, *ch 2, 3 dc into the ring; repeat from * twice more, ch 2, join with a slip stitch to the top of the beginning ch 3.
        Row 2: Ch 3 (counts as dc), in the same space work 2 dc, ch 2, 3 dc, *ch 1, 3 dc in the next ch-2 space, ch 2, 3 dc, repeat from * around, join with a slip stitch to the top of the beginning ch 3.
        (Continue with additional rows as desired.)
        """
    ),
    CrochetPattern(
        name: "Ribbed Crochet Hat",
        category: "Hat Patterns",
        instructions: """
        Round 1: Start with a magic ring, ch 2 (counts as hdc), work 9 hdc into the ring, join with a slip stitch to the top of the beginning ch 2.
        Round 2: Ch 2 (counts as hdc), work 1 hdc in the same stitch, 2 hdc in each stitch around, join with a slip stitch to the top of the beginning ch 2.
        (Continue increasing until desired diameter, then work even in hdc until hat measures desired length.)
        """
    ),
    CrochetPattern(
        name: "Basketweave Stitch",
        category: "Stitch Patterns",
        instructions: """
        Row 1: Ch any multiple of 6 + 4 (e.g., 22), dc in 4th ch from hook, dc in each ch across.
        Row 2: Ch 3 (counts as dc), turn, fpdc in next 3 sts, bpdc in next 3 sts, *fpdc in next 3 sts, bpdc in next 3 sts; repeat from * to end.
        (Continue alternating Rows 1 and 2 to create the basketweave pattern.)
        """
    ),
    CrochetPattern(
        name: "Shell Stitch Baby Blanket",
        category: "Blanket Patterns",
        instructions: """
        Foundation: Chain a multiple of 6 + 3 (e.g., 105).
        Row 1: Dc in 4th ch from hook, *skip 2 ch, 5 dc in next ch, skip 2 ch, dc in next ch; repeat from * across, turn.
        Row 2: Ch 3 (counts as dc), 2 dc in first dc, *skip 2 dc, sc in next dc, skip 2 dc, 5 dc in next sc; repeat from * across, ending with 3 dc in last dc, turn.
        (Continue alternating Rows 1 and 2 to create the shell stitch pattern.)
        """
    ),
    CrochetPattern(
        name: "Crocodile Stitch Gloves",
        category: "Accessory Patterns",
        instructions: """
        Row 1: Ch the desired length for wrist circumference, sc in the second ch from the hook and across.
        Rows 2-4: Ch 1, turn, sc in each st across.
        Row 5: Ch 2 (counts as hdc), turn, hdc in the first st, *ch 1, skip 1 st, hdc in the next st; repeat from * across.
        (Continue to create the crocodile stitch pattern for the desired length.)
        """
    ),
    CrochetPattern(
        name: "Triangle Shawl",
        category: "Shawl Patterns",
        instructions: """
        Row 1: Ch 4, 3 dc in the first ch.
        Row 2: Ch 4 (counts as dc and ch 1), turn, dc in the first st, ch 1, 2 dc in the same st, ch 1, dc in the top of the turning ch.
        (Continue increasing by working 2 dc, ch 1, 2 dc in the center st across each row until the shawl reaches the desired size.)
        """
    )
]
