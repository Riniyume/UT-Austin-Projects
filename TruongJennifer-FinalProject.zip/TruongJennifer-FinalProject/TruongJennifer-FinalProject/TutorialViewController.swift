//
//  Project: TruongJennifer-FinalProject
//  EID: jat5244
//  Course: CS329E
//
//  TutorialViewController.swift
//  TruongJennifer-FinalProject
//
//  Created by Jennifer Truong on 11/30/23.
//

import UIKit

class TutorialViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var tutorialTable: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tutorialTable.delegate = self
        tutorialTable.dataSource = self
    }
    
    // Return the number of rows in the table view
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return crochetTutorials.count
    }
    
    // Provide cells for the table view
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "tutorialCell", for: indexPath)
        
        // Access the tutorial data for the corresponding row
        let tutorial = crochetTutorials[indexPath.row]
        
        // Set the cell's text labels using tutorial data
        cell.textLabel?.text = tutorial.title
        cell.detailTextLabel?.text = "Difficulty: \(tutorial.difficulty)"
        
        return cell
    }
    
    // MARK: - Navigation
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "tutorialPageSegue" {
            
            // Check if a row is selected in the table view
            if let indexPath = tutorialTable.indexPathForSelectedRow {
                // Get the selected tutorial
                let selectedTutorial = crochetTutorials[indexPath.row]
                // Pass the selected tutorial to the TutorialPageViewController
                if let tutorialPageVC = segue.destination as? TutorialPageViewController {
                    tutorialPageVC.selectedTutorial = selectedTutorial
                }
            }
        }
    }
}
