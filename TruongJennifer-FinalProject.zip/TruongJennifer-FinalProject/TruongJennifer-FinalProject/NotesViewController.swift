//
//  Project: TruongJennifer-FinalProject
//  EID: jat5244
//  Course: CS329E
//
//  NotesViewController.swift
//  TruongJennifer-FinalProject
//
//  Created by Jennifer Truong on 12/3/23.
//

import UIKit
import Foundation
import CoreData

// Pointer to something outside of the app
let appDelegate = UIApplication.shared.delegate as! AppDelegate
// Creating a buffer, lazy way, note pad
let context = appDelegate.persistentContainer.viewContext

class NotesViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, AddNoteDelegate {
    
    @IBOutlet weak var notesTable: UITableView!
    var notes: [Note] = sampleNotes // Using sampleNotes as initial data
    var coreDataNotes: [Note] = [] // Separate array for CoreData notes
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        notesTable.delegate = self
        notesTable.dataSource = self
        
        // Load notes from CoreData on view load
        coreDataNotes = loadNotes()
        
        // Combine sampleNotes and coreDataNotes for display
        notes += coreDataNotes
        
        // Reload the table view to reflect the updated notes
        notesTable.reloadData()
    }
    
    // MARK: - Table View Data Source Methods
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return notes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // Setting up table view cells with note data
        let cell = tableView.dequeueReusableCell(withIdentifier: "noteCell", for: indexPath)
        let note = notes[indexPath.row]
        cell.textLabel?.text = note.title
        return cell
    }
    
    // MARK: - Table View Delegate Methods
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // Handling row selection: navigating to edit note view
        let selectedNote = notes[indexPath.row]
        performSegue(withIdentifier: "editNoteSegue", sender: selectedNote)
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        // Handling row deletion: removing note from the data source
        if editingStyle == .delete {
            // Delete the row from the data source
            let deletedNote = notes.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
            
            // Call the function to delete the note from Core Data
            deleteNoteFromCoreData(note: deletedNote)
        }
    }
    
    // MARK: - AddNoteDelegate Methods
    
    func addNewNote(_ note: Note) {
        // Handling addition of a new note: updating table view
        notes.append(note)
        notesTable.reloadData()
    }
    
    func updateNote(_ updatedNote: Note) {
        // Handling note update: refreshing table view
        for (index, note) in notes.enumerated() {
            if note.title == updatedNote.title {
                notes[index] = updatedNote
                notesTable.reloadData()
                return
            }
        }
    }
    
    // Function to add a new note to CoreData
    func addNewNoteToCoreData(title: String, content: String) {
        guard let entity = NSEntityDescription.entity(forEntityName: "NoteObject", in: context) else {
            print("Error: Entity not found")
            return
        }
        
        let newNote = NSManagedObject(entity: entity, insertInto: context)
        newNote.setValue(title, forKey: "title")
        newNote.setValue(content, forKey: "content")
        
        // Save the context after adding the new note
        saveContext()
    }

    // MARK: - Navigation
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "addNoteSegue" {
            if let destinationVC = segue.destination as? NotesPageViewController {
                destinationVC.delegate = self
            }
        } else if segue.identifier == "editNoteSegue" {
            if let destinationVC = segue.destination as? NotesPageViewController {
                destinationVC.delegate = self
                if let selectedNote = sender as? Note {
                    destinationVC.selectedNote = selectedNote
                }
            }
        }
    }
    
    // MARK: - Helper functions for managing CoreData operations
    
    func loadNotes() -> [Note] {
        // Fetching notes from CoreData and converting into Note objects
        let fetchRequest: NSFetchRequest<NSManagedObject> = NSFetchRequest(entityName: "NoteObject")
        
        do {
            let fetchedResults = try context.fetch(fetchRequest)
            var noteList = [Note]()
            
            for managedObject in fetchedResults {
                guard
                    let title = managedObject.value(forKey: "title") as? String,
                    let content = managedObject.value(forKey: "content") as? String
                else {
                    continue
                }
                let note = Note(title: title, content: content)
                note.title = title
                note.content = content
                noteList.append(note)
            }
            
            return noteList
        } catch {
            // Error handling for data retrieval failure
            print("Error occurred while retrieving data: \(error)")
            return []
        }
    }
    
    func deleteNoteFromCoreData(note: Note) {
        // Deleting a note from CoreData based on title and content match
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "NoteObject")
        // Construct a predicate based on the unique identifier of the note
        let predicate = NSPredicate(format: "title = %@ AND content = %@", note.title, note.content)
        
        request.predicate = predicate
        
        do {
            if let result = try context.fetch(request) as? [NSManagedObject], let firstObject = result.first {
                context.delete(firstObject)
                saveContext()
            }
        } catch {
            // Error handling for data deletion failure
            print("Error occurred while deleting data: \(error)")
        }
    }
    
    func retrieveNotes() -> [NSManagedObject] {
        let fetchRequest: NSFetchRequest<NSManagedObject> = NSFetchRequest(entityName: "NoteObject")

        do {
            let fetchedResults = try context.fetch(fetchRequest)
            return fetchedResults
        } catch {
            // Error handling for data retrieval failure
            print("Error occurred while retrieving data: \(error)")
            return []
        }
    }
    
    func saveContext() {
        // Saving changes made to the CoreData context
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }

}
