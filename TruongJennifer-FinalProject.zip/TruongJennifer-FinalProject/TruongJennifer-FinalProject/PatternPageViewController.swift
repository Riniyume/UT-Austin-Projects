//
//  Project: TruongJennifer-FinalProject
//  EID: jat5244
//  Course: CS329E
//
//  PatternPageViewController.swift
//  TruongJennifer-FinalProject
//
//  Created by Jennifer Truong on 11/30/23.
//

import UIKit

class PatternPageViewController: UIViewController {

    @IBOutlet weak var patternName: UILabel!
    @IBOutlet weak var category: UILabel!
    @IBOutlet weak var instructionLabel: UILabel!
    
    // Property to hold selected pattern info
    var selectedPattern: CrochetPattern?
    
    // Array to hold bookmarked patterns
    var bookmarkedPatterns: [CrochetPattern] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let pattern = selectedPattern {
            // Populate labels with details from the selected pattern
            patternName.text = pattern.name
            category.text = "Category: \(pattern.category)"
            instructionLabel.text = pattern.instructions
        }
    }
}
