//
//  Project: TruongJennifer-FinalProject
//  EID: jat5244
//  Course: CS329E
//
//  PatternViewController.swift
//  TruongJennifer-FinalProject
//
//  Created by Jennifer Truong on 11/30/23.
//

import UIKit

class PatternViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var patternTable: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        patternTable.delegate = self
        patternTable.dataSource = self
    }
    
    // Return the number of rows in the table view
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return crochetPatterns.count
    }
    
    // Provide cells for the table view
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "patternCell", for: indexPath)
        
        // Access the pattern data for the corresponding row
        let pattern = crochetPatterns[indexPath.row]
        
        // Set the cell's text labels using pattern data
        cell.textLabel?.text = pattern.name
        cell.detailTextLabel?.text = "Category: \(pattern.category)"
        
        return cell
    }

    // MARK: - Navigation
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "patternPageSegue" {
            // Check if a row is selected in the table view
            if let indexPath = patternTable.indexPathForSelectedRow {
                // Get the selected pattern
                let selectedPattern = crochetPatterns[indexPath.row]
                // Pass the selected pattern to the PatternPageViewController
                if let patternPageVC = segue.destination as? PatternPageViewController {
                    patternPageVC.selectedPattern = selectedPattern
                }
            }
        }
    }

}
