//
//  Project: TruongJennifer-FinalProject
//  EID: jat5244
//  Course: CS329E
//
//  RegisterViewController.swift
//  TruongJennifer-FinalProject
//
//  Created by Jennifer Truong on 12/4/23.
//

import UIKit
import FirebaseAuth

class RegisterViewController: UIViewController {

    // Outlets for text fields and labels
    @IBOutlet weak var emailAddress: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var confirmPassword: UITextField!
    
    @IBOutlet weak var confirmPasswordLabel: UILabel!
    @IBOutlet weak var statusLabel: UILabel!
    
    // Outlets for segmented control and buttons
    @IBOutlet weak var registerSegment: UISegmentedControl!
    @IBOutlet weak var registerButton: UIButton!
    
    // Delegate for sign-out functionality
    weak var signOutDelegate: SignOutDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Login screen default: confirm password label and textfield hidden
        // Also have the button label changed
        registerButton.setTitle("Sign In", for: .normal)
        confirmPassword.isHidden = true
        confirmPasswordLabel.isHidden = true
        
        self.statusLabel.text = ""
        
        // Listen for changes in the user's authentication state
        Auth.auth().addStateDidChangeListener() {
            (auth,user) in
            // If a user is authenticated, perform a segue to another screen
            if user != nil {
                self.performSegue(withIdentifier: "registerSegue", sender: nil)
                self.emailAddress.text = nil      // Clear the user ID text field
                self.password.text = nil    // Clear the password text field
                self.confirmPassword.text = nil     // Clear the confirm password text field
                
                // Idk why my signout isn't working like the way I want to
                // so roundabout fix...
                self.registerSegment.selectedSegmentIndex = 0
                self.registerButton.setTitle("Sign In", for: .normal)
                self.confirmPassword.isHidden = true
                self.confirmPasswordLabel.isHidden = true
            }
        }
    }
    
    // Handle segmented control changes
    @IBAction func segmentedControlChanged(_ sender: UISegmentedControl) {
        if sender.selectedSegmentIndex == 0 {
            // Log In Screen
            registerButton.setTitle("Sign In", for: .normal)
            confirmPassword.isHidden = true
            confirmPasswordLabel.isHidden = true
        } else {
            // Sign Up Screen
            registerButton.setTitle("Sign Up", for: .normal)
            confirmPassword.isHidden = false
            confirmPasswordLabel.isHidden = false
        }
    }
    
    // Handle sign-in or sign-up button tap
    @IBAction func signInOrSignUp(_ sender: UIButton) {
        guard let email = emailAddress.text, !email.isEmpty,
              let passwords = password.text, !passwords.isEmpty else {
            statusLabel.text = "Email and password are required."
            return
        }
        
        if registerSegment.selectedSegmentIndex == 0 {
            // Log In Screen
            Auth.auth().signIn(withEmail: emailAddress.text!, password: password.text!) { [weak self] (authResult, error) in
                guard let self = self else { return }
                
                if let error = error as NSError? {
                    self.statusLabel.text = "\(error.localizedDescription)"
                } else {
                    // Successful login - segue to home screen or perform necessary actions
                    self.performSegue(withIdentifier: "registerSegue", sender: nil)
                }
            }
            
        } else {
            // Sign Up Screen
            
            // Check if both password inputs match
            guard let confirmPasswords = confirmPassword.text, confirmPasswords == passwords else {
                statusLabel.text = "Passwords do not match."
                return
            }
            
            Auth.auth().createUser(withEmail: emailAddress.text!, password: password.text!) { [weak self] (authResult, error) in
                guard let self = self else { return }
                
                if let error = error as NSError? {
                    self.statusLabel.text = "\(error.localizedDescription)"
                } else {
                    // Successful signup - segue to home screen or perform necessary actions
                    self.performSegue(withIdentifier: "registerSegue", sender: nil)
                }
            }
        }
    }
    
    func didSignOut() {
        // set the segmented control to the "Sign In" segment
        registerSegment.selectedSegmentIndex = 0

        // - Clear text fields
        emailAddress.text = ""
        password.text = ""
        confirmPassword.text = ""
    }
    
}
