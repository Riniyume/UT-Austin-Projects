//
//  Project: TruongJennifer-FinalProject
//  EID: jat5244
//  Course: CS329E
//
//  TutorialPageViewController.swift
//  TruongJennifer-FinalProject
//
//  Created by Jennifer Truong on 11/30/23.
//

import UIKit

class TutorialPageViewController: UIViewController {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var difficultyLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    
    // Property to hold selected tutorial info
    var selectedTutorial: CrochetTutorial?
    
    // Array to hold bookmarked tutorials
    var bookmarkedTutorials: [CrochetTutorial] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let tutorial = selectedTutorial {
            // Populate labels with details from the selected tutorial
            titleLabel.text = tutorial.title
            difficultyLabel.text = "Difficulty: \(tutorial.difficulty)"
            descriptionLabel.text = tutorial.description
        }
    }
    
}
