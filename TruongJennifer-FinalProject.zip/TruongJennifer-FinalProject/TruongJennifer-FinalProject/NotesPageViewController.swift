//
//  Project: TruongJennifer-FinalProject
//  EID: jat5244
//  Course: CS329E
//
//  NotesPageViewController.swift
//  TruongJennifer-FinalProject
//
//  Created by Jennifer Truong on 12/3/23.
//

import UIKit
import Foundation
import CoreData

class NotesPageViewController: UIViewController {
    
    @IBOutlet weak var noteTitle: UITextField!
    @IBOutlet weak var noteTextView: UITextView!
    
    weak var delegate: AddNoteDelegate?
    var selectedNote: Note? // Property to hold the selected note
    
    var appDelegate: AppDelegate!
    var context: NSManagedObjectContext!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Accessing CoreData context from the app's AppDelegate
        appDelegate = UIApplication.shared.delegate as? AppDelegate
        context = appDelegate.persistentContainer.viewContext
        
        // Pre-fill UI elements if a note is selected for editing
        if let note = selectedNote {
            // For editing existing note
            noteTitle.text = note.title
            noteTextView.text = note.content
        } else {
            // Placeholder and default content for adding a new note
            noteTitle.placeholder = "Enter Title"
            noteTextView.text = "Enter Note Content"
        }
    }
    
    // Save the new note into table view when button pressed
    @IBAction func DoneButtonPressed(_ sender: Any) {
        guard let title = noteTitle.text, !title.isEmpty,
              let content = noteTextView.text, !content.isEmpty else {
            return
        }
        
        // If selectedNote exists, it's an edit. If not, it's a new note.
        if let existingNote = selectedNote {
            // Editing an existing note
            existingNote.title = title
            existingNote.content = content
            delegate?.updateNote(existingNote)
            // Save changes to Core Data
            saveContext()
        } else {
            // Adding a new note to Core Data
            addNewNoteToCoreData(title: title, content: content)
        }
        // Go back to the previous view controller
        navigationController?.popViewController(animated: true)
    }
    
    // Function to add a new note to Core Data
    func addNewNoteToCoreData(title: String, content: String) {
        guard let entity = NSEntityDescription.entity(forEntityName: "NoteObject", in: context) else {
            print("Error: Entity not found")
            return
        }
        
        let newNote = NSManagedObject(entity: entity, insertInto: context)
        newNote.setValue(title, forKey: "title")
        newNote.setValue(content, forKey: "content")
        
        // Save the context after adding the new note
        saveContext()
    }
    
    // Function to save changes in Core Data context
    func saveContext() {
        if context.hasChanges {
            do {
                try context.save()
                print("CoreData Saved Changes")
            } catch {
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }
}
