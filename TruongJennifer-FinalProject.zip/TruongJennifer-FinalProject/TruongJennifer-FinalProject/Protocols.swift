//
//  Project: TruongJennifer-FinalProject
//  EID: jat5244
//  Course: CS329E
//
//  Protocols.swift
//  TruongJennifer-FinalProject
//
//  Created by Jennifer Truong on 12/3/23.
//

import Foundation

// For the notes
protocol AddNoteDelegate: AnyObject {
    func addNewNote(_ note: Note)
    func updateNote(_ note: Note)
}

// For the Signout button
protocol SignOutDelegate: AnyObject {
    func didSignOut()
}
