//
//  Project: TruongJennifer-FinalProject
//  EID: jat5244
//  Course: CS329E
//
//  HomeViewController.swift
//  TruongJennifer-FinalProject
//
//  Created by Jennifer Truong on 11/29/23.
//

import UIKit

class HomeViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

}
