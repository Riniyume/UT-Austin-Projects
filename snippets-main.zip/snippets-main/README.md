#### This is the snippets repo for Elements of Databases Fall 2023
##### In here you will find code samples and guides for our class weekly assignments and projects 
