To run the code: Open the .pde file and click 'Run' to display the image. 

In order to choose a filter within the program, press the following number keys
for the filters you would like to switch to. 

Filters:
0 - no filter
1 - grayscale
2 - contrast
3 - gaussian blur
4 - edge detection