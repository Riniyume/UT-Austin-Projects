DIRECTIONS:
To run the code: Open the .pde file and click 'Run' for the program to start.
------------------------------------------------------------------------------------------------------------------------------ 

INFORMATION:

- LEFT click the mouse to change the color to pastel pink.
- RIGHT click the mouse to change the color to pastel purple.
- PRESS KEY "r" for a RED rectangle on display screen. It will stay, unless you move the mouse. Then it will reappear.
- PRESS KEY "g" for a GREEN rectangle on display screen. It will stay, unless you move the mouse. Then it will reappear.
- PRESS KEY "b" for a BLUE rectangle on display screen. It will stay, unless you move the mouse. Then it will reappear.

NOTES:
I'm aware it's a bit buggy, but I did the best I could.