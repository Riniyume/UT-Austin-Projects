// TruongJennifer-HW1
// UT EID: jat5244
// Course: CS329E

// Create a weapon class
class Weapon {
    var weaponType: String
    var damage: Int
    
    // Listing out the damages for each available weapon
    init(weaponType: String){
        self.weaponType = weaponType
        switch weaponType {
        case "dagger":
            damage = 4
        case "axe":
            damage = 6
        case "staff":
            damage = 6
        case "sword":
            damage = 10
        case "none":
            damage = 1
        default:
            damage = 1
        }
    }
}

// Create an armor class
class Armor {
    var armorType: String
    var armorClass: Int
    
    // Listing out the protection effect for each armor
    // Although the effect is not implemented
    init(armorType: String) {
        self.armorType = armorType
        switch armorType {
        case "plate":
            armorClass = 2
        case "chain":
            armorClass = 5
        case "leather":
            armorClass = 8
        case "none":
            armorClass = 10
        default:
            armorClass = 10
        }
    }
}

// Create RPGCharacter class
class RPGCharacter {
    var name: String
    var maxHealthPoints: Int
    var currentHealthPoints: Int
    var currentSpellPoints: Int
    var armor: Armor?
    var weapon: Weapon?
    
    init(name: String) {
        self.name = name
        self.maxHealthPoints = 0 // initializing
        self.currentHealthPoints = maxHealthPoints
        self.currentSpellPoints = 0
        self.armor = nil
        self.weapon = nil
    }
    
    // Define allowed weapon types for the character class
    func allowedWeaponTypes() -> [String] {
        return []
    }
    
    // Define allowed armor types for the character class
    func allowedArmorTypes() -> [String] {
        return []
    }
    
    // Wield function where a character can use a weapon if allowed
    func wield(weaponObject: Weapon) {
        let allowedTypes = allowedWeaponTypes()
        if allowedTypes.contains(weaponObject.weaponType) {
            self.weapon = weaponObject
            print("\(name) is now wielding a(n) \(weaponObject.weaponType)")
        } else {
            print("Weapon not allowed for this character class.")
        }
    }
    
    // Unwield a weapon function
    func unwield() {
        weapon = nil
        print("\(name) is no longer wielding anything")
    }
    
    // Put on armor function if it's allowed for the character type
    func putOnArmor(armorObject: Armor) {
        let allowedTypes = allowedArmorTypes()
        if allowedTypes.contains(armorObject.armorType) {
            self.armor = armorObject
            print("\(name) is now wearing \(armorObject.armorType)")
        } else {
            print("Armor not allowed for this character class")
        }
    }
    
    // Take off armor function
    func takeOffArmor() {
        armor = nil
        print("\(name) is no longer wearing anything.")
    }
    
    // Fight a character function
    func fight(opponent: RPGCharacter) {
        // if the character has a weapon, then attack
        if let myWeapon = weapon {
            print("\(name) attacks \(opponent.name) with a(n) \(myWeapon.weaponType)")
            
            let damageDone = myWeapon.damage
            opponent.currentHealthPoints -= damageDone
            print("\(name) does \(damageDone) damage to \(opponent.name)")
            print("\(opponent.name) is now down to \(opponent.currentHealthPoints) health")
            
            // check if opponent is defeated and print the statement if so
            checkForDefeat(character: opponent)
            
        } else {
            // if the character does not wield a weapon
            print("\(name) attacks \(opponent.name) with bare hands")
            opponent.currentHealthPoints -= 1
            print("\(name) does 1 damage to \(opponent.name)")
            print("\(opponent.name) is now down to \(opponent.currentHealthPoints) health")
        }
    }

    // Check for character defeat
    func checkForDefeat(character: RPGCharacter) {
            if character.currentHealthPoints <= 0 {
                print("\(character.name) has been defeated!")
            }
        }
    
    // Show character information stats
    func show() {
        print("\(name)")
        print("   Current Health: \(currentHealthPoints)")
        print("   Current Spell Points: \(currentSpellPoints)")
        if let wieldingWeapon = weapon {
            print("   Wielding: \(wieldingWeapon.weaponType)")
        } else {
            print("   Wielding: none")
        }
        if let wearingArmor = armor {
            print("   Wearing: \(wearingArmor.armorType)")
            print("   Armor class: \(wearingArmor.armorClass)")
        } else {
            print("   Wearing: none")
            print("   Armor class: 10")
        }
    }
}

// Create a Fighter class
class Fighter: RPGCharacter {
    let maxSpellPoints: Int = 0
    
    override init(name: String) {
        super.init(name: name)
        self.maxHealthPoints = 40
        self.currentHealthPoints = maxHealthPoints
    }
    
    // Override the main class for the allowed weapon types
    override func allowedWeaponTypes() -> [String] {
        return ["dagger", "axe", "staff", "sword"]
    }
    
    // Override the main class for the allowed armor types
    override func allowedArmorTypes() -> [String] {
        return ["plate","chain","leather","none"]
    }
}

// Create a Wizard class
class Wizard: RPGCharacter {
    let maxSpellPoints: Int = 20
    
    override init(name: String) {
        super.init(name: name)
        self.maxHealthPoints = 16
        self.currentHealthPoints = maxHealthPoints
        self.currentSpellPoints = maxSpellPoints
    }
    
    // Override the main class for the allowed weapon types
    override func allowedWeaponTypes() -> [String] {
        return ["dagger", "staff"]
    }
    
    // Override the main class for no armor types allowed!
    override func allowedArmorTypes() -> [String] {
        return ["none"]
    }
    
    // Cast Spells function
    func castSpell(spellName: String, target: RPGCharacter) {
        var spellCost = 0
        var spellEffect = 0
        
        // List of spell names with their costs and damages
        switch spellName {
        case "Fireball":
            spellCost = 3
            spellEffect = 5
        case "Lightning Bolt":
            spellCost = 10
            spellEffect = 10
        case "Heal":
            spellCost = 6
            spellEffect = -6
        default:
            print("Unknown spell name. Spell failed.")
            return
        }
        
        // Check if there's enough spell points to continue casting spells
        if currentSpellPoints < spellCost {
            print ("Insufficient spell points")
            return
        }
        
        // Print the dialogue action
        print("\(name) cast \(spellName) at \(target.name)")
        
        // If the spell is heal, so heal character, but capped at their maxHealth
        if spellName == "Heal" {
            target.currentHealthPoints = min(target.maxHealthPoints, target.currentHealthPoints - spellEffect)
            print("\(name) heals \(target.name) for \(abs(spellEffect)) health points")
            print("\(target.name) is now at \(target.currentHealthPoints) health.")
        } else {
            // Any other valid spell that isn't heal
            target.currentHealthPoints -= spellEffect
            print("\(name) does \(spellEffect) damage to \(target.name)")
            print("\(target.name) is now down to \(target.currentHealthPoints) health.")
            
            // Check if the opponent is defeated
            checkForDefeat(character: target)
        }
        
        // Deduct the spellCost from the spell points
        currentSpellPoints -= spellCost
    }
}

// Main Program Code
let plateMail = Armor(armorType: "plate")
let chainMail = Armor(armorType: "chain")
let sword = Weapon(weaponType: "sword")
let staff = Weapon(weaponType: "staff")
let axe = Weapon(weaponType: "axe")

let gandalf = Wizard(name: "Gandalf the Grey")
gandalf.wield(weaponObject: staff)

let aragorn = Fighter(name: "Aragorn")
aragorn.putOnArmor(armorObject: plateMail)
aragorn.wield(weaponObject: axe)

gandalf.show()
aragorn.show()

gandalf.castSpell(spellName: "Fireball", target: aragorn)
aragorn.fight(opponent: gandalf)

gandalf.show()
aragorn.show()

gandalf.castSpell(spellName: "Lightning Bolt", target: aragorn)
aragorn.wield(weaponObject: sword)
 
gandalf.show()
aragorn.show()
 
gandalf.castSpell(spellName: "Heal", target: gandalf)
aragorn.fight(opponent: gandalf)
 
gandalf.fight(opponent: aragorn)
aragorn.fight(opponent: gandalf)
 
gandalf.show()
aragorn.show()
