//
// Project: TruongJennifer-HW9
// EID: jat5244
// Course: CS329E
//
//  ViewController.swift
//  TruongJennifer_HW9
//
//  Created by Jennifer Truong on 11/16/23.
//

import UIKit

class ViewController: UIViewController {
    
    var blockView: UIView!
    var isMoving = false // Flag to track block movement
    var isGameOver = false // Flag to track game over state
    let gridSize = CGSize(width: UIScreen.main.bounds.width / 9, height: UIScreen.main.bounds.height / 19)
    var blockSize = CGSize(width: UIScreen.main.bounds.width / 9, height: UIScreen.main.bounds.height / 19)
    var currentDirection: MovementDirection = .none
    var blockMovementTimer: Timer?
    
    // Enumeration representing different movement directions
    enum MovementDirection {
        case none, up, down, left, right
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        createBlock()
    }
    
    // Create the block object
    func createBlock() {
        let safeAreaFrame = view.safeAreaLayoutGuide.layoutFrame
        blockSize = CGSize(width: safeAreaFrame.width / 9, height: safeAreaFrame.height / 19)
        
        // Creating the block view and positioning it in the center of the screen
        blockView = UIView(frame: CGRect(origin: CGPoint(x: safeAreaFrame.midX - blockSize.width / 2, y: safeAreaFrame.midY - blockSize.height / 2), size: blockSize))
        blockView.backgroundColor = .green // Setting block color to green
        view.addSubview(blockView) // Adding the block view to the main view
    }
    
    // Tap Gesture to start or restart the game event
    @IBAction func tapGestureAction(_ sender: Any) {
        if isGameOver {
            isGameOver = false
            isMoving = false // Reset the moving flag
            currentDirection = .down // Set the direction to down
            resetBlockPosition()
            startBlockMovement()
        } else {
            // Start block movement on tap even when not game over
            currentDirection = .down // Set direction to down
            startBlockMovement()
        }
    }
    
    // Resetting block position to the center
    func resetBlockPosition() {
        // Move the block to the center of the grid world
        blockView.center = CGPoint(x: UIScreen.main.bounds.midX, y: UIScreen.main.bounds.midY)
        blockView.backgroundColor = .green // Reset block color
    }
    
    // Starting block movement
    func startBlockMovement() {
        guard !isMoving else { return } // Check if block is already moving
        
        // Invalidate the existing timer if it exists
        blockMovementTimer?.invalidate()
        
        isMoving = true
        // Timer to move the block at regular intervals
        blockMovementTimer = Timer.scheduledTimer(withTimeInterval: 0.3, repeats: true) { timer in
            // Move the block according to the current direction
            self.moveBlockByOneBlockWidth(self.currentDirection)
            
            // Check if the block reaches the bottom boundary
            if self.blockView.frame.maxY >= UIScreen.main.bounds.maxY {
                timer.invalidate()
                self.isMoving = false
                self.blockView.backgroundColor = .red // Change color to red
                self.isGameOver = true // Set game over state
            }
        }
    }
    
    // Method to move the block by one grid unit
    func moveBlockByOneBlockWidth(_ direction: MovementDirection) {
        guard !isGameOver else { return } // Check if game over
        
        var newXPosition = blockView.frame.origin.x
        var newYPosition = blockView.frame.origin.y
        
        switch direction {
        case .up:
            newYPosition -= gridSize.height
        case .down:
            newYPosition += gridSize.height
        case .left:
            newXPosition -= gridSize.width
        case .right:
            newXPosition += gridSize.width
        case .none:
            return
        }
        
        // Calculate the right edge considering the safe area
        let rightEdge = UIScreen.main.bounds.width - blockSize.width
        
        // Check if the new position is within bounds
        if newXPosition >= 0 && newYPosition >= 0 && newXPosition <= rightEdge && newYPosition + blockSize.height <= UIScreen.main.bounds.height {
            blockView.frame.origin = CGPoint(x: newXPosition, y: newYPosition)
        } else {
            // Block reached the edge, change color and stop movement
            blockView.backgroundColor = .red
            isMoving = false
            isGameOver = true
        }
    }
    
    // Gesture handlers for directional movement
    @IBAction func upSwipeGesture(_ sender: Any) {
        currentDirection = .up
    }
    
    @IBAction func downSwipeGesture(_ sender: Any) {
        currentDirection = .down
    }
    
    @IBAction func leftSwipeGesture(_ sender: Any) {
        currentDirection = .left
    }
    
    @IBAction func rightSwipeGesture(_ sender: Any) {
        currentDirection = .right
    }
    
}

