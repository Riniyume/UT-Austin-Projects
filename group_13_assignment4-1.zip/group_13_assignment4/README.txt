Directions: 

Open the group_13_assignment4.pde and click "Run" to start the program. 

