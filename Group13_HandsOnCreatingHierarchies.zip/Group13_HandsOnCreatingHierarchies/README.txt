Written explanation of who is working on what for the scene hierarchy graph:

Object 1 (Zehua (Jake)): Create a car that will move on its own in a defined area(the road), while its wheels rotate.


Object 2 (Aanand): Create a cloud shape that rotates while the car moves.The animation here is that whatever shape it is,
 it will keep moving and while it rotates in the centre. Could also potentially have a list of different shapes and randomly
 select shapes to display as clouds.  

Object 3 (Jennifer): Create the sun and the moon, where both are technically the same object. However, the sun will move left
 to right, and the moon will appear from right to left and this will be repetitive and continuous. Also, the sun will have
 sunshine rays, while the moon will have craters. The two different objects: sun/moon with the sunshine rays and craters are
 different based on the shape, size, and color. Both rays and craters will follow either moon or sun in the rotation pattern
 with similar speed. 
