Directions:
Open the .pde file and click "Run" to start the program
-----------------------------------------------------------------------------------------------------------------------------
Information:
This was suppose to look like a bird with a worm in it's beak while wearing a hat.