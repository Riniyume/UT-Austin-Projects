//
//  Project: TruongJennifer-HW7
//  EID: jat5244
//  Course: CS329E
//
//  CountdownViewController.swift
//  TruongJennifer-HW7
//
//  Created by Jennifer Truong on 10/28/23.
//

import UIKit

class CountdownViewController: UIViewController {
    // Outlets for labels in the Countdown View Controller
    @IBOutlet var eventLabel: UILabel!
    @IBOutlet var locationLabel: UILabel!
    @IBOutlet var remainingTimeLabel: UILabel!
    
    // The timer to be displayed and counted down
    var timersClock: Timer!
    var countdownThread: DispatchWorkItem? // to handle the countdown
    var mainViewController: ViewController?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Check if a timer is provided
        if let timing = timersClock {
            // Update labels with timer information
            eventLabel.text = timing.event
            locationLabel.text = timing.location
            remainingTimeLabel.text = "\(timing.remainingTime) seconds"
            
            countdownThread = DispatchWorkItem { [weak self] in
                var remainingTime = timing.remainingTime
                
                while remainingTime > 0 {
                    // Delay the countdown for 1 second
                    Thread.sleep(forTimeInterval: 1)
                    remainingTime -= 1
                    
                    // Update the UI on the main thread
                    DispatchQueue.main.async {
                        self?.remainingTimeLabel.text = "\(remainingTime) seconds"
                    }
                }
                // Perform some action when the countdown reaches 0
                // Update the remaining time in the MainViewController
                if let mainVC = self?.mainViewController,
                   let timerIndex = mainVC.timersList.firstIndex(where: { $0 === timing }) {
                    mainVC.timersList[timerIndex].remainingTime = remainingTime
                    
                    // Update the table view on the main thread
                    DispatchQueue.main.async {
                        mainVC.tableView.reloadData()
                    }
                }
            }
            // Start the countdown thread
            if let countdownThread = countdownThread {
                DispatchQueue.global().async(execute: countdownThread)
            }
        }
    }
    // Handle actions when leaving the Countdown View Controller
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        // Stop the countdown thread when leaving this view
        countdownThread?.cancel()
        
        // Update the remaining time in the MainViewController
        if let mainVC = mainViewController,
           let timerIndex = mainVC.timersList.firstIndex(where: { $0 === timersClock }) {
            mainVC.timersList[timerIndex].remainingTime = timersClock.remainingTime
            
            // Update the table view on the main thread
            DispatchQueue.main.async {
                mainVC.tableView.reloadData()
                
            }
        }
    }
}
