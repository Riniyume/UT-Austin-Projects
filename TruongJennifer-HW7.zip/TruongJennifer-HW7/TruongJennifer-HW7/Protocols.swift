//
//  Project: TruongJennifer-HW7
//  EID: jat5244
//  Course: CS329E
//
//  Protocols.swift
//  TruongJennifer-HW7
//
//  Created by Jennifer Truong on 10/30/23.
//

import Foundation

protocol AddTimerDelegate: AnyObject {
    func didCreateNewTimer(_ timer: Timer)
}
