//
//  Project: TruongJennifer-HW7
//  EID: jat5244
//  Course: CS329E
//
//  AddTimerViewController8.swift
//  TruongJennifer-HW7
//
//  Created by Jennifer Truong on 10/30/23.
//

import UIKit

class AddTimerViewController8: UIViewController {
    
    // Outlets for text fields in the Add Timer View Controller
    @IBOutlet weak var eventTextField: UITextField!
    @IBOutlet weak var locationTextField: UITextField!
    @IBOutlet weak var totalTimeTextField: UITextField!
     
    var timersList: [Timer] = []
    // Delegate to notify when a new timer is created
    weak var delegate: AddTimerDelegate?
     
    override func viewDidLoad() {
        super.viewDidLoad()
    }
     
    // Action method called when the "Save" button is tapped
    @IBAction func saveButtonTapped(_ sender: Any) {
        // Get user input from text fields
        let event = eventTextField.text!
        let location = locationTextField.text!
         
        // Convert the input to an integer
        let initialRemainingTime = Int(totalTimeTextField.text ?? "0")!

        // Create a new Timer object with user input
        let newTimer = Timer(event: event, location: location, remainingTime: initialRemainingTime)

        // Add the new timer to the timersList??
        timersList.append(newTimer)

        // Notify the delegate that a new timer was created
        delegate?.didCreateNewTimer(newTimer)
         
        // Dismiss the Add Timer View Controller
        dismiss(animated: true, completion: nil)
    }
}
