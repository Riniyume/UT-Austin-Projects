//
//  Project: TruongJennifer-HW7
//  EID: jat5244
//  Course: CS329E
//
//  ViewController.swift
//  TruongJennifer-HW7
//
//  Created by Jennifer Truong on 10/28/23.
//

import UIKit

// Timer class
class Timer {
    var event: String
    var location: String
    var remainingTime: Int

    init(event: String, location: String, remainingTime: Int) {
        self.event = event
        self.location = location
        self.remainingTime = remainingTime
    }
}

// Sub-class for the custom table view
class TimerTableViewCell: UITableViewCell {
    @IBOutlet weak var eventCellLabel: UILabel!
    @IBOutlet weak var locationCellLabel: UILabel!
    @IBOutlet weak var remainingTimeCellLabel: UILabel!
}

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, AddTimerDelegate {

    @IBOutlet weak var tableView: UITableView!
    
    // Declare and initialize the timers array
    var timersList: [Timer] = []
    
    // Identifier for the segue to the Add Timer View Controller
    let segueAddButtonIdentifier = "createTimerSegueIdentifier"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Set the table view's delegate and data source to this view controller
        tableView.delegate = self
        tableView.dataSource = self
    }
    
    // Return the number of rows in the table view
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return timersList.count
    }
    
    // Display the timer information in the table view cells
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TimerTableViewCell", for: indexPath) as! TimerTableViewCell
        let timer = timersList[indexPath.row]
        cell.eventCellLabel.text = "Event: \(timer.event)"
        cell.locationCellLabel.text = "Location: \(timer.location)"
        cell.remainingTimeCellLabel.text = "Remaining time(s): \(timer.remainingTime) secs"
        return cell
    }
    
    // If user selects a row, then segue to Countdown VC
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedTimer = timersList[indexPath.row]
        // Perform a segue to the Countdown View Controller, passing the selected timer as needed.
        performSegue(withIdentifier: "countdownSegueIdentifier", sender: selectedTimer)
    }
    
    // Implement the protocol method
    func didCreateNewTimer(_ timer: Timer) {
        // Add the new timer to your timersList
        timersList.append(timer)

        // Reload the table view to reflect the changes
        tableView.reloadData()
        }
    
    // Prepare for segues to other view controllers
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == segueAddButtonIdentifier {
            // Prepare for the segue to the Add Timer View Controller
            if let addTimerVC = segue.destination as? AddTimerViewController8 {
                addTimerVC.delegate = self
            }
        }

        if segue.identifier == "countdownSegueIdentifier" {
            // Prepare for the segue to the Countdown View Controller
            if let countdownVC = segue.destination as? CountdownViewController {
                if let selectedTimer = sender as? Timer {
                    countdownVC.timersClock = selectedTimer
                }
            }
        }
    }

}
