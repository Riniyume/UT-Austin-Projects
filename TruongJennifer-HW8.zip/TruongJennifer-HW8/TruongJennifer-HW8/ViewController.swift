//
// Project: TruongJennifer-HW8
// EID: jat5244
// Course: CS329E
//
//  ViewController.swift
//  TruongJennifer-HW8
//
//  Created by Jennifer Truong on 10/31/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var button: UIButton!
    // Counter to keep track of button clicks
    var clickCount = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set up the button and add the tap action
        button.setImage(UIImage(named: "uttower"), for: .normal)
        button.addTarget(self, action: #selector(buttonTapped), for: .touchUpInside)
        
        // Request notification permissions
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound]) { (granted, error) in
            if granted {
                print("Notification permission granted")
            } else if let error = error {
                print("Notification permission error: \(error)")
            }
        }
    }
    
    @objc func buttonTapped() {
        if clickCount % 2 == 0 {
            // Animation 1 - Fade out
            UIView.animate(withDuration: 1.0, delay: 0.0, options: .curveEaseOut, animations: {
                self.button.alpha = 0.0
            }) { (completed) in
                // Animation 2 - Change image and fade in
                self.button.setImage(UIImage(named: "ut"), for: .normal)
                UIView.animate(withDuration: 1.0, delay: 0.0, options: .curveEaseIn, animations: {
                    self.button.alpha = 1.0
                }, completion: nil)
            }
        } else {
            // Animation 1 - Fade out
            UIView.animate(withDuration: 1.0, delay: 0.0, options: .curveEaseOut, animations: {
                self.button.alpha = 0.0
            }) { (completed) in
                // Animation 2 - Change image and fade in
                self.button.setImage(UIImage(named: "uttower"), for: .normal)
                UIView.animate(withDuration: 1.0, delay: 0.0, options: .curveEaseIn, animations: {
                    self.button.alpha = 1.0
                }, completion: nil)
            }
        }
        // Increment the click count
        clickCount += 1
        
        // Trigger a notification after 4 clicks or clicks by 4's
        if clickCount % 4 == 0 {
            scheduleLocalNotification()
        }
    }
    
    // Make the notification schedule
    func scheduleLocalNotification() {
        let content = UNMutableNotificationContent()
        content.title = "Click Count"
        content.subtitle = "Keep tapping!"
        content.body = "You have clicked \(clickCount) times"
        
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 8, repeats: false)
        let request = UNNotificationRequest(identifier: "clickCountNotification", content: content, trigger: trigger)
        
        UNUserNotificationCenter.current().add(request) { (error) in
            if let error = error {
                print("Error scheduling notification: \(error)")
            }
        }
    }
    
}

