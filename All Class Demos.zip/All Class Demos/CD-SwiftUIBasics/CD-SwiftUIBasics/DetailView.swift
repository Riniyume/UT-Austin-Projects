//
//  DetailView.swift
//  CD-SwiftUIBasics
//
//  Created by bulko on 11/15/23.
//

import SwiftUI

struct DetailView: View {
    var body: some View {
        Text("I'm in love with the shape of you.")
    }
}

#Preview {
    DetailView()
}
