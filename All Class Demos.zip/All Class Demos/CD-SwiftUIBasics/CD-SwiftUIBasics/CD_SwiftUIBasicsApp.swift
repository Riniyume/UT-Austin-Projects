//
//  CD_SwiftUIBasicsApp.swift
//  CD-SwiftUIBasics
//
//  Created by bulko on 11/13/23.
//

import SwiftUI

@main
struct CD_SwiftUIBasicsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
