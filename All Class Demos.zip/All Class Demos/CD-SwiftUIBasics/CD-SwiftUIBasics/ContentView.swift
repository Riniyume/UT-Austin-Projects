//
//  ContentView.swift
//  CD-SwiftUIBasics
//
//  Created by bulko on 11/13/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
            VStack(alignment: .leading) {
                Text("Ed Sheeran")
                    .font(.title)
                HStack {
                    Text("Rock Star")
                        .font(.subheadline)
                    Spacer()
                    Text("+1-512-555-SING")
                        .font(.subheadline)
                }
                NavigationLink (
                    destination: DetailView(),
                    label: {
                        Text("Press on me")
                            .frame(minWidth:0,maxWidth:100)
                            .padding(10)
                            .foregroundColor(.white)
                            .background(Color(.gray))
                            .cornerRadius(40)
                    })
            }
            .padding()
        }
    }
}

#Preview {
    ContentView()
}
