//
//  ViewController.swift
//  CD-Multithreading
//
//  Created by bulko on 10/23/23.
//

import UIKit

class ViewController: UIViewController {
    
    var queue: DispatchQueue!
    
    var dot: UIView!
    var xLeft: Double = 0.0
    var xRight: Double = 0.0
    var y: Double = 0.0

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // size of dot:  initially, a square, 100 x 100
        let dotHeight = 100.0
        let dotWidth = 100.0
        
        // two horizontal positions of the top left corner of the dot
        // xLeft is 50 pixels from the left edge
        // xRight is 150 pixels from the right edge
        xLeft = dotWidth / 2.0
        xRight = self.view.bounds.width - (1.5 * dotWidth)
        
        // one vertical position: centered vertically on the screen
        y = (self.view.bounds.height / 2.0) - (dotHeight / 2.0)
        
        dot = UIView(frame: CGRect(x: xLeft, y: y, width: dotWidth, height: dotHeight))
        dot.backgroundColor = .red
        dot.layer.cornerRadius = dotWidth/2.0
        
        self.view.addSubview(dot)
        
        queue = DispatchQueue(label: "myQueue",qos: .utility)
        
        queue.async {
            self.moveBlock()
        }
    }

    func moveBlock() {

        var toggle = "left"
        
        while true {
            
            usleep(300000)
            
            if toggle == "left" {
                toggle = "right"
                DispatchQueue.main.async {
                    self.dot.frame.origin.x = self.xRight
                }
            } else {
                toggle = "left"
                DispatchQueue.main.async {
                    self.dot.frame.origin.x = self.xLeft
                }
            }
            
        }


    }

}

