//
//  ViewController.swift
//  demoLocation
//
//  Created by bulko on 10/20/16.
//  Copyright © 2016 bulko. All rights reserved.
//

import UIKit
import CoreLocation

class ViewController: UIViewController, CLLocationManagerDelegate {

    @IBOutlet weak var latitude: UILabel!
    @IBOutlet weak var longitude: UILabel!
    @IBOutlet weak var horizontalAccuracy: UILabel!
    @IBOutlet weak var altitude: UILabel!
    @IBOutlet weak var verticalAccuracy: UILabel!
    @IBOutlet weak var distance: UILabel!
    
    
    var locationManager: CLLocationManager = CLLocationManager()
    var startLocation: CLLocation!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        locationManager.delegate = self
        
        startLocation = nil
        locationManager.desiredAccuracy = kCLLocationAccuracyBest       // Use the "best accuracy" setting
        locationManager.requestWhenInUseAuthorization()                 // Ask user for permission to use location
        locationManager.startUpdatingLocation()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func resetDistance(_ sender: Any) {
            startLocation = nil
    }
    
    func locationManager(_ manager: CLLocationManager,
                         didUpdateLocations locations: [CLLocation])

    {
        let latestLocation:CLLocation = locations[locations.count - 1]
        
        latitude.text = String(format: "%.4f",
                               latestLocation.coordinate.latitude)
        longitude.text = String(format: "%.4f",
                                latestLocation.coordinate.longitude)
        horizontalAccuracy.text = String(format: "%.4f",
                                         latestLocation.horizontalAccuracy)
        altitude.text = String(format: "%.4f",
                               latestLocation.altitude)
        verticalAccuracy.text = String(format: "%.4f",
                                       latestLocation.verticalAccuracy)
        
        
        if startLocation == nil {
            startLocation = latestLocation
        }
        
        distance.text = String(format: "%.2f",
                               latestLocation.distance(from: startLocation))
    }

}

