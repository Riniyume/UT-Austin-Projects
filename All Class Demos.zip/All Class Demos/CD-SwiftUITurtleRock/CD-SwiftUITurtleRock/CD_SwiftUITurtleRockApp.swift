//
//  CD_SwiftUITurtleRockApp.swift
//  CD-SwiftUITurtleRock
//
//  Created by bulko on 11/17/23.
//

import SwiftUI

@main
struct CD_SwiftUITurtleRockApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
