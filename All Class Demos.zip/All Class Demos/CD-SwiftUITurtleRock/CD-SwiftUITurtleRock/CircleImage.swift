//
//  CircleImage.swift
//  CD-SwiftUITurtleRock
//
//  Created by bulko on 11/17/23.
//

import SwiftUI

struct CircleImage: View {
    var body: some View {
        Image("turtlerock")
            .clipShape(Circle())
            .overlay(
                Circle()
                    .stroke(Color.white,lineWidth: 4))
            .shadow(radius: 10)
    }
}

#Preview {
    CircleImage()
}
