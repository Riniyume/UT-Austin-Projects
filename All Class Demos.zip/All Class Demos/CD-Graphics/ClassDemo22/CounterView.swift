//
//  CounterView.swift
//  ClassDemo22
//
//  Created by bulko on 4/21/22.
//

import UIKit

let NoOfSettings = 8                    // # of settings on the dial
let π:CGFloat = CGFloat(Double.pi)      // type the π using Option-p

@IBDesignable class CounterView: UIView {

    @IBInspectable var counter:Int = 5  {
        didSet {
            if counter <= NoOfSettings {        // this only happens up to 8
                setNeedsDisplay()               // redraw the arc
            }
        }
    }
    @IBInspectable var outlineColor:UIColor = .blue
    @IBInspectable var counterColor:UIColor = .orange
    
    override func draw(_ rect: CGRect) {
        
        // create the arc background
        let center = CGPoint(x: bounds.width/2, y: bounds.height/2)
        let radius: CGFloat = max(bounds.width,bounds.height)
        
        // thickness of the arc
        let arcWidth:CGFloat = 76
        let startAngle = 3 * π/4
        let endAngle = π/4
        
        // create a path for the arc I just defined
        var path = UIBezierPath(
            arcCenter: center,
            radius: radius/2 - arcWidth/2,
            startAngle: startAngle,
            endAngle: endAngle,
            clockwise: true)
        
        // set the line width and color
        path.lineWidth = arcWidth
        counterColor.setStroke()
        path.stroke()
        
        // draw the outline of the arc
        
        // calculate the difference between the two angles, ensuring
        //    that it's positive
        let angleDifference:CGFloat = 2 * π - startAngle + endAngle
        
        // then calculate the arc for each setting on the dial
        let arcLengthPerSetting = angleDifference / CGFloat(NoOfSettings)
        
        // then multiply out by the actual setting
        let outlineEndAngle = arcLengthPerSetting * CGFloat(counter) + startAngle
        
        // draw the outer arc
        var outlinePath = UIBezierPath(
            arcCenter: center,
            radius: bounds.width/2 - 2.5,
            startAngle: startAngle,
            endAngle: outlineEndAngle,
            clockwise: true)
        
        // draw the inner arc
        outlinePath.addArc(
            withCenter: center,
            radius: bounds.width/2 - arcWidth + 2.5,
            startAngle: outlineEndAngle,
            endAngle: startAngle,
            clockwise: false)
        
        // finish it
        outlinePath.close()
        outlineColor.setStroke()
        outlinePath.lineWidth = 5.0
        outlinePath.stroke()
    }

}
