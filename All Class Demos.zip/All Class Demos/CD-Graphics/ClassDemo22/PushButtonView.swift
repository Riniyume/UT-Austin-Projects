//
//  PushButtonView.swift
//  ClassDemo22
//
//  Created by bulko on 4/19/22.
//

import UIKit

@IBDesignable class PushButtonView: UIButton {
    
    @IBInspectable var fillColor:UIColor = UIColor.green
    @IBInspectable var isAddButton:Bool = true

    override func draw(_ rect: CGRect) {
        var path = UIBezierPath(ovalIn: rect)
        fillColor.setFill()
        path.fill()
        
        // set up the width and height variables for the horizontal stroke
        // a path 3 pixels wide, 60% of the circle long
        let lineThickness = 3.0
        let lineLength = min(bounds.width,bounds.height) * 0.6
        
        // create the path
        var plusPath = UIBezierPath()
        plusPath.lineWidth = lineThickness
        
        // ************** HORIZONTAL STROKE *******************
        plusPath.move(to: CGPoint(x: bounds.width/2 - lineLength/2, y:bounds.height/2))
        plusPath.addLine(to: CGPoint(x: bounds.width/2 + lineLength/2, y: bounds.height/2))
        
        if isAddButton {
            // *************** VERTICAL STROKE ********************
            plusPath.move(to: CGPoint(x: bounds.width/2, y:bounds.height/2 - lineLength/2))
            plusPath.addLine(to: CGPoint(x: bounds.width/2, y: bounds.height/2 + lineLength/2))
        }
        // other stuff
        UIColor.white.setStroke()
        plusPath.stroke()
        
    }

}
