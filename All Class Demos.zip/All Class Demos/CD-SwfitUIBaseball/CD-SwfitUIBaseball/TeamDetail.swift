//
//  TeamDetail.swift
//  CD-SwfitUIBaseball
//
//  Created by bulko on 11/27/23.
//

import SwiftUI

var previewTeam = Team(city: "Austin", name: "Ice Bats", league: "Hockey")

struct TeamDetail: View {
    var team: Team
    
    var body: some View {
        VStack {
            Text(team.city)
                .font(.system(size:24))
            Text(team.name)
                .font(.system(size:30))
        }
    }
}

#Preview {
    TeamDetail(team: previewTeam)
}
