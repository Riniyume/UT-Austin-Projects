//
//  TeamRow.swift
//  CD-SwfitUIBaseball
//
//  Created by bulko on 11/27/23.
//

import SwiftUI

struct TeamRow: View {
    var team: Team
    
    var body: some View {
        VStack {
            Text(team.name)
                .font(.title)
            HStack {
                Text(team.city)
                    .font(.subheadline)
                Spacer()
                Text(team.league)
                    .font(.subheadline)
            }
        }
    }
}

#Preview {
    TeamRow(team: teams[8])
}
