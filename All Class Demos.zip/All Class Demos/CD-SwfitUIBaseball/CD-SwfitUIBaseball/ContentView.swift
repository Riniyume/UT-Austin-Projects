//
//  ContentView.swift
//  CD-SwfitUIBaseball
//
//  Created by bulko on 11/27/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
            List(teams) { team in
                NavigationLink(destination: TeamDetail(team:team)) {
                    TeamRow(team: team)
                }
            }
            .navigationBarTitle(Text("Teams"))
        }
    }
}

#Preview {
    ContentView()
}
