//
//  CD_SwfitUIBaseballApp.swift
//  CD-SwfitUIBaseball
//
//  Created by bulko on 11/27/23.
//

import SwiftUI

@main
struct CD_SwfitUIBaseballApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
