//
//  ViewController.swift
//  CD-Calendar
//
//  Created by bulko on 11/29/23.
//

import UIKit
import EventKit

class ViewController: UIViewController {

    @IBOutlet weak var eventLabel: UILabel!
    
    let eventStore = EKEventStore()
    var savedEventId:String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    func createEvent(title:String, startDate:NSDate, endDate:NSDate) {
        
        let event = EKEvent(eventStore: eventStore)
        event.title = title
        event.startDate = startDate as Date
        event.endDate = endDate as Date
        event.calendar = eventStore.defaultCalendarForNewEvents
        
        do {
            try eventStore.save(event, span: .thisEvent)
            savedEventId = event.eventIdentifier
            eventLabel.text = "Event added to calendar"
        } catch {
            print("Error")
        }
        
    }
    
    @IBAction func addEventSelected(_ sender: Any) {
        
        let startDate = NSDate()
        let endDate = startDate.addingTimeInterval(60*60)
        
        eventStore.requestFullAccessToEvents() {
            (granted,error) in
            if granted {
                self.createEvent(title: "Polish my bowling trophies",
                                 startDate: startDate,
                                 endDate: endDate)
            } else {
                print("Error again")
            }
        }
    }
    
    func deleteEvent(eventIdentifier:String) {
        let eventToRemove = eventStore.event(withIdentifier: eventIdentifier)
        
        if (eventToRemove != nil) {
            do {
                try eventStore.remove(eventToRemove!, span: .thisEvent)
                eventLabel.text = "Event removed from calendar"
            } catch {
                print("Yet another error")
            }
        }
        
    }
    
    @IBAction func removeEventSelected(_ sender: Any) {
        
        eventStore.requestFullAccessToEvents() {
            (granted,error) in
            self.deleteEvent(eventIdentifier: self.savedEventId)
        }
        
    }
    
}

