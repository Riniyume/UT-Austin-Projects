//
//  ViewController.swift
//  CD-CoreData
//
//  Created by bulko on 10/11/23.
//

import UIKit
import CoreData

let appDelegate = UIApplication.shared.delegate as! AppDelegate
let context = appDelegate.persistentContainer.viewContext

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        demoCoreData()
    }

    func demoCoreData() {
        
        // REMEMBER TO CREATE A DATA MODEL IN THE .xcdatamodeld FILE FIRST!
        
        print("\n\nStarting Core Data Demo")
        
        clearCoreData()

        storePerson(name: "Justin Timberlake", age: 42)
        storePerson(name: "Alicia Keys", age: 42)
        storePerson(name: "Billie Eilish", age: 21)
        storePerson(name: "Carrie Underwood", age: 40)
        print("Stored four people")
        
        let fetchedResults = retrievePeople()
        
        for person in fetchedResults {
            if let personName = person.value(forKey: "name") {
                if let personAge = person.value(forKey: "age") {
                    print("Retrieved: \(personName), age \(personAge)")
                }
            }
        }
    }
    
    func clearCoreData() {
        // erase everything currently in Core Data
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Person")
        var fetchedResults:[NSManagedObject]
        
        do {
            try fetchedResults = context.fetch(request) as! [NSManagedObject]
        
            if fetchedResults.count > 0 {
                for result in fetchedResults {
                    context.delete(result)
                    print("\(result.value(forKey: "name")!) has been deleted")
                }
            }
            saveContext()
        } catch {
            print("Error occurred while clearing data")
            abort()
        }
    }
    
    func storePerson(name:String, age:Int32) {
        // create a Person and store it in Core Data
        
        let person = NSEntityDescription.insertNewObject(
            forEntityName: "Person",
            into: context)
        
        person.setValue(name, forKey: "name")
        person.setValue(age, forKey: "age")
        
        // commit the changes
        saveContext()
        
    }
    
    func retrievePeople() -> [NSManagedObject] {
        // retrieve all of the Person objects in Core Data
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Person")
        var fetchedResults:[NSManagedObject]? = nil
        
        let predicate = NSPredicate(format: "name CONTAINS[c] 'ie'")
        request.predicate = predicate
        
        do {
            try fetchedResults = context.fetch(request) as? [NSManagedObject]
        } catch {
            print("Error occured while retrieving data")
            abort()
        }
        
        return (fetchedResults)!
    }

    func saveContext () {
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }
    
}

