//
//  MyCollectionViewCell.swift
//  CD-Collections
//
//  Created by bulko on 11/1/23.
//

import UIKit

class MyCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var myLabel: UILabel!
    
}
