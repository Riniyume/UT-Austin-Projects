//
//  ViewController.swift
//  CD-FirstApp
//
//  Created by bulko on 9/5/23.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var nameField: UITextField!
    @IBOutlet weak var messageLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        nameField.delegate = self
    }

    @IBAction func buttonPressed(_ sender: Any) {
        
        // retrieve the text contained in the text field
        let name = nameField.text!
        
        // create a message using that text
        let message = "\(name) pressed the button"
        
        // put the message into the status label
        messageLabel.text = message
        
    }
    
    // Called when 'return' key pressed
    
    func textFieldShouldReturn(_ textField:UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    // Called when the user clicks on the view outside of the UITextField
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
}

