Directions:
Open .pde and click "run" to start the program.
-----------------------------------------------------------------------------------------------------------------------------
press 'r' = increase red value
press 'R' = decrease red value
press 'g' = increase green value
press 'G' = decrease green value
press 'b' = increase blue value
press 'B' = decrease blue value

press 'x' = increase x value
press 'X' = decrease x value
press 'y' = increase y value
press 'Y' = decrease y value
press 'z' = increase z value
press 'Z' = decrease z value

press 'UP' = increase concentration value
press 'DOWN' = decrease concentration value
press 'LEFT' = increase angle value
press 'RIGHT' = decrease angle value
