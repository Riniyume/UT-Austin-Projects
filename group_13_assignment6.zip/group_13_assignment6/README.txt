Open the .pde and click run to start the program. This is an interactive physics simulation, so move the mouse to aim the cannon and click to shoot a bullet. 
