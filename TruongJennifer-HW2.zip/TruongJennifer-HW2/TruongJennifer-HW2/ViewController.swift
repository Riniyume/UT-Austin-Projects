//
//  Project: TruongJennifer-HW2
//  EID: Jat5244
//  Course: CS329E
//
//  ViewController.swift
//  TruongJennifer-HW2
//
//  Created by Jennifer Truong on 9/7/23.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    
    // Create @IBOutlets for two text fields and status label
    @IBOutlet weak var userNameField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var statusLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    // Create a button that will change the status label when
    // the user logged in. Space counts as text
    @IBAction func buttonPressed(_ sender: Any) {
        // create the invalid login message
        let invalidMessage = "Invalid login"
        
        // Check if userNameField is empty
        if let userName = userNameField.text, !userName.isEmpty {
            
            // Check if passwordField is empty
            if let password = passwordField.text, !password.isEmpty {
                
                // Create message using the text
                let loginMessage = "\(userName) logged in"
                
                // Put message into the status label (loginMessageLabel)
                statusLabel.text = loginMessage
                
            } else {
                // PasswordField is empty
                statusLabel.text = invalidMessage
            }
            
        } else {
            // userNameField is empty
            statusLabel.text = invalidMessage
        }
    }
    
    // Code to dismiss the keyboard:
    // Called when 'return' key pressed
    func textFieldShouldReturn(_ textField:UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    // Called when the user clicks on the view outside of the UITextField
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
}

