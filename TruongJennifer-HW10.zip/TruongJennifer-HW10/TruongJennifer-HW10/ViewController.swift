//
// Filename: TruongJennifer-HW10
// EID: jat5244
// Course: CS329E
//
//  ViewController.swift
//  TruongJennifer-HW10
//
//  Created by Jennifer Truong on 11/19/23.
//

import UIKit
import AVFoundation

class ViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    // Data source array to store selected images
    var photoCollection: [UIImage] = []
    
    let reuseIdentifier = "MyCell"
    let picker = UIImagePickerController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set delegates and data source for the collection view
        collectionView.dataSource = self
        collectionView.delegate = self
        
        // Set up picker delegate for handling image selection
        picker.delegate = self
    }
    
    // Configure cells in the collection view
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath)
        
        // Remove any existing image views in the cell's content view
        for subview in cell.contentView.subviews {
            subview.removeFromSuperview()
        }
        
        // Create and configure image view in the cell
        let imageView = UIImageView(frame: cell.contentView.bounds)
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        
        let image = photoCollection[indexPath.item]
        imageView.image = image
        
        cell.contentView.addSubview(imageView)
        return cell
    }
    
    // Return number of items in the collection view
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return photoCollection.count
    }
    
    // Action for adding photos from the system album: Left button
    @IBAction func addFromSystemAlbum (_ sender: Any) {
        picker.sourceType = .photoLibrary
        present(picker, animated: true, completion: nil)
    }
    
    // Action for adding photos from the camera: Right button
    @IBAction func addFromCamera (_ sender: Any) {
        // Check for camera availability and authorization
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            // Check camera authorization status
            switch AVCaptureDevice.authorizationStatus(for: .video) {
            case .notDetermined:
                AVCaptureDevice.requestAccess(for: .video) { granted in
                    if granted {
                        // Access granted, present the camera picker
                        DispatchQueue.main.async {
                            self.showCameraPicker()
                        }
                    } else {
                        // Access denied
                        self.showCameraAccessDeniedAlert()
                    }
                }
            case .authorized:
                // Camera access already authorized, present the camera picker
                self.showCameraPicker()
            default:
                // Access denied
                self.showCameraAccessDeniedAlert()
            }
        } else {
            // Handle the case where the device doesn't have a camera
            let alertVC = UIAlertController(
                title: "No Camera",
                message: "Sorry, this device has no camera",
                preferredStyle: .alert)
            let okAction = UIAlertAction(title: "OK", style: .default)
            alertVC.addAction(okAction)
            present(alertVC, animated: true)
        }
    }
    
    // Alert for informing user about camera access denial
    func showCameraAccessDeniedAlert() {
        let alert = UIAlertController(
            title: "Camera Access Denied",
            message: "To take photos, please enable camera access in Settings.",
            preferredStyle: .alert
        )
        
        // Option to cancel the alert
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        // Option to open settings to enable camera access
        alert.addAction(UIAlertAction(title: "Settings", style: .default) { _ in
            if let settingsURL = URL(string: UIApplication.openSettingsURLString) {
                if UIApplication.shared.canOpenURL(settingsURL) {
                    UIApplication.shared.open(settingsURL)
                }
            }
        })
        
        present(alert, animated: true, completion: nil)
    }

    // Function to present the UIImagePickerController for camera capture
    func showCameraPicker() {
        picker.sourceType = .camera
        picker.allowsEditing = false
        picker.delegate = self
        present(picker, animated: true, completion: nil)
    }
    
    // Handle selected image from the image picker
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let selectedImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            photoCollection.append(selectedImage)
            collectionView.reloadData()
        }
        picker.dismiss(animated: true, completion: nil)
    }
    
    // Dismiss image picker on cancel
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    
    // Segue to Detail View Controller
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "detailSegueIdentifier" {
            if let indexPath = collectionView.indexPathsForSelectedItems?.first {
                let selectedImage = photoCollection[indexPath.item]
                if let destinationVC = segue.destination as? DetailViewController {
                    destinationVC.selectedImage = selectedImage
                }
            }
        }
    }
}

// Extension to handle collection view layout
extension ViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let paddingSpace: CGFloat = 10 // Adjust as needed
        let availableWidth = collectionView.bounds.width - paddingSpace * 4 // Three cells with padding
        let widthPerItem = availableWidth / 3
        return CGSize(width: widthPerItem, height: widthPerItem)
    }
}

