//
// Filename: TruongJennifer-HW10
// EID: jat5244
// Course: CS329E
//
//  DetailViewController.swift
//  TruongJennifer-HW10
//
//  Created by Jennifer Truong on 11/27/23.
//

import UIKit

class DetailViewController: UIViewController {
    
    var selectedImage: UIImage?
    @IBOutlet weak var detailImageView: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Check if selectedImage is not nil before assigning to the imageView
        if let image = selectedImage {
            detailImageView.image = image
        } else {
            // Handle the case when selectedImage is nil
            print("Selected image is nil")
        }
    }
}

